<?php
  require_once '../app/bootstrap.php';
//  echo "Welcome to One Management !! ";
  // Init Core Library
  $init = new Core;