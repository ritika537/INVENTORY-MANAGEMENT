<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of User
 *
 * @author Software Development Wing <Penta Head Private Ltd.>
 */
class Inventorys extends Controller
{

    public function __construct()
    {
        // echo 'Agents construct';
        $this->inventoryModel = $this->model('Inventory');
        $todaysDate = null;
    }

    public function adminLogmeIn()
    {

        // $this->view('admin/dashboard');
        $this->view('commons/register');
    }

    public function logmein()
    {
        // $this->view('inventorymanagement/main');
        $this->view('commons/register');

    }

    public function navForm()
    {
        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            $_POST = filter_input_array(INPUT_POST, FILTER_SANITIZE_STRING);
            if (isset($_POST['dashboard'])) {
                $this->view('inventorymanagement/main');
            } else if (isset($_POST['product_scan'])) {
                // $data = $this->inventoryModel->getAllBill();
                $this->view('inventorymanagement/product_scan');
            } else if (isset($_POST['product_inventory'])) {
                $data = $this->inventoryModel->getAllUserProduct();
                $this->view('inventorymanagement/product_inventory', $data);
            } else if (isset($_POST['teacher'])) {
                $this->view('inventorymanagement/teacher');
            } else if (isset($_POST['invoice'])) {
                $this->view('inventorymanagement/invoice');
            }else if (isset($_POST['userviewprofile'])) {
                $this->view('inventorymanagement/userviewprofile');
            }
        }
    }
    // getAllAdminProduct
    public function adminnavForm()
    {
        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            $_POST = filter_input_array(INPUT_POST, FILTER_SANITIZE_STRING);
            if (isset($_POST['dashboard'])) {
                $this->view('admin/dashboard');
            } else if (isset($_POST['addproduct'])) {
                $this->view('admin/addproduct');
            } else if (isset($_POST['userinfo'])) {
                $this->view('admin/userinfo');
            } else if (isset($_POST['addcategory'])) {
                $data = $this->inventoryModel->getAllCategory();
                $this->view('admin/addcategory', $data);
            } else if (isset($_POST['admin_product_inventory'])) {
                $data = $this->inventoryModel->getAllAdminProduct();
                $this->view('admin/admin_product_inventory', $data);
            } else if (isset($_POST['viewprofile'])) {
                $this->view('admin/viewprofile');
            }
        }
    }

    public function adminRegister()
    {
        // echo "hello";

        // if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        //     $_POST = filter_input_array(INPUT_POST, FILTER_SANITIZE_STRING);
        //     echo "hiii";
        //     $data['message'] = null;
        //     if (isset($_POST['login'])) {
        //         $data = [
        //             'userid' => trim($_POST['login_id']),
        //             'password' => trim($_POST['password']),
        //             'role' => trim($_POST['role'])
        //         ];
        //         $matched = $this->inventoryModel->login_verification($data);
        //         //  echo "efsdv".$matched;
        //         if ($matched == true && $data['userid'] == 'admin' && $data['role'] == 'Admin') {
        //             echo "efsdv" . $matched;
        //             // print_r($data);
        //             $this->view('admin/dashboard', $data);
        //         }

        //     } else {

        //         $data['message'] = " Invalid Password  !! ";
        // $this->view('commons/register');
        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            // Sanitize input data
            $_POST = filter_input_array(INPUT_POST, FILTER_SANITIZE_STRING);

            // Initialize message variable
            $data['message'] = null;

            // Check if form is submitted
            if (isset($_POST['submit'])) {
                // Extract form data    
                $name = trim($_POST['name']);
                $email = trim($_POST['email']);
                $phone = trim($_POST['phone']);
                $dob = trim($_POST['dob']);
                $city = trim($_POST['city']);
                $state = trim($_POST['state']);
                $zip_code = trim($_POST['zip_code']);
                $address = trim($_POST['address']);
                // $address2 = trim($_POST['address2']);
                // $id = trim($_POST['id']);
                $password = trim($_POST['password']);
                $role = trim($_POST['role']);
                // image
                $targetDir = "uploads/"; 
                $allowTypes = array('jpg','png','jpeg'); 
                $statusMsg = $errorMsg = $insertResult = $errorUpload = $errorUploadType = ''; 
                $image = array_filter($_FILES['image']['name']); 
               if(!empty($image)){ 
                   foreach($_FILES['image']['name'] as $key=>$val){ 
                        // File upload path 
                        $image = basename($_FILES['image']['name'][$key]); 
                        $targetFilePath = $targetDir . $image; 
                         
                        // Check whether file type is valid 
                        $fileType = pathinfo($targetFilePath, PATHINFO_EXTENSION); 
                        if(in_array($fileType, $allowTypes)){ 
                            // Upload file to server 
                            if(move_uploaded_file($_FILES["image"]["tmp_name"][$key], $targetFilePath)){ 
                                // Image db insert sql 
                                $insertResult .= "('".$image."', NOW()),"; 
                                $Id = $this->inventoryModel->insertRegistration($name, $email, $phone, $dob, $city, $state, $zip_code, $address, $password, $role,$image);
                               if ($Id != null){
                                    $data['message']="Profile completed successfully !!";
                               }
                               else{
                                    $data['message']="Failed to add data, please try again !!";
                               } 
                           }
                       } 
                   } 
               }

                // $insertResult = $this->inventoryModel->insertUserInfo($name, $email, $phone, $dob, $city, $state, $zip_code, $address1, $address2, $id, $password, $role);
                // $insertResult = $this->inventoryModel->insertRegistration($name, $email, $phone, $dob, $city, $state, $zip_code, $address, $password, $role, $imageName);


                // Check if insertion was successful
                // if ($insertResult) {
                //     // Insertion successful, set success message
                //     $data['message'] = "User information added successfully.";
                // } else {
                //     // Insertion failed, set error message
                //     $data['message'] = "Failed to add user information. Please try again.";
                // }

                // Load the view with appropriate message
                $this->view('commons/login', $data);
            } else if (isset($_POST['loginbtn'])) {
                // $data = $this->inventoryModel->getAllUserView();
                $this->view('commons/login');
            }
        }

    }


    public function adminLoginDetails()
    {
        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            $_POST = filter_input_array(INPUT_POST, FILTER_SANITIZE_STRING);
            // echo "hiii";
            $data['message'] = null;
            if (isset($_POST['loginbtn'])) {
                $data = [
                    'email' => trim($_POST['login_id']),
                    'password' => trim($_POST['password']),
                    'role' => trim($_POST['role'])
                ];
                 $matched = $this->inventoryModel->login_verification($data);
                //   echo "efsdv".$matched;
                 if ($matched == true && $data['email'] == 'admin@gmail.com' && $data['role'] == 'Admin') {
                    //  echo "efsdvaaaaa" . $matched;
                    //  print_r($data);
                     $this->view('admin/dashboard', $data);
                 } else if($matched == true && $data['email'] =='user@gmail.com' && $data['role']=='User'){
                    // $this->createUserSession($data['userid']);
                    $this->view('inventorymanagement/main');
            }
                // $this->view('admin/dashboard', $data);

            // }
             else  {

                $data['message'] = " Invalid Password  !! ";
                $this->view('commons/login', $data);
                //  $this->view('admin/dashboard', $data);
            }
            // else if(isset($_POST['registerbtn'])) {
            //     // $data = $this->inventoryModel->getAllUserView();
            //     $this->view('commons/register');
             }
        }
    }



    // userinfo 
    // public function userInfo()
    // {
    //     if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    //         // Sanitize input data
    //         $_POST = filter_input_array(INPUT_POST, FILTER_SANITIZE_STRING);

    //         // Initialize message variable
    //         $data['message'] = null;

    //         // Check if form is submitted
    //         if (isset($_POST['submit'])) {
    //             // Extract form data    
    //             $fullname = trim($_POST['fullname']);
    //             $email = trim($_POST['email']);
    //             $phone = trim($_POST['phone']);
    //             $dob = trim($_POST['dob']);
    //             $city = trim($_POST['city']);
    //             $state = trim($_POST['state']);
    //             $pincode = trim($_POST['pincode']);
    //             $address1 = trim($_POST['address1']);
    //             $address2 = trim($_POST['address2']);
    //             $id = trim($_POST['id']);
    //             $password = trim($_POST['password']);
    //             $role = trim($_POST['role']);

    //             $insertResult = $this->inventoryModel->insertUserInfo($fullname, $email, $phone, $dob, $city, $state, $pincode, $address1, $address2, $id, $password, $role);

    //             // Check if insertion was successful
    //             if ($insertResult) {
    //                 // Insertion successful, set success message
    //                 $data['message'] = "User information added successfully.";
    //             } else {
    //                 // Insertion failed, set error message
    //                 $data['message'] = "Failed to add user information. Please try again.";
    //             }

    //             // Load the view with appropriate message
    //             $this->view('admin/userinfo', $data);
    //         } else if (isset($_POST['viewuserbtn'])) {
    //             $data = $this->inventoryModel->getAllUserView();
    //             $this->view('admin/viewuserprofile', $data);
    //         }
    //     }
    // }


    public function userInfo()
    {
        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            // Sanitize input data
            $_POST = filter_input_array(INPUT_POST, FILTER_SANITIZE_STRING);

            // Initialize message variable
            $data['message'] = null;

            // Check if form is submitted
            if (isset($_POST['submit'])) {
                // Check if an image file was uploaded
                if (isset($_FILES['profileImage']) && $_FILES['profileImage']['error'] === UPLOAD_ERR_OK) {
                    $imageTmpName = $_FILES['profileImage']['tmp_name'];
                    $imageName = $_FILES['profileImage']['name'];

                    // Move the uploaded file to a permanent location
                    $uploadDirectory = 'uploads/'; // Specify the directory where you want to store uploaded images
                    $targetPath = $uploadDirectory . $imageName;

                    if (move_uploaded_file($imageTmpName, $targetPath)) {
                        // File uploaded successfully, store the path in the database or use it as needed
                        // You can save $targetPath in your database along with other user information
                        $data['message'] = "User image added successfully.";
                    } else {
                        // Failed to move the uploaded file, handle the error
                        $data['message'] = "Failed to add user image. Please try again.";
                    }
                }

                // Extract form data    
                $fullname = trim($_POST['fullname']);
                $email = trim($_POST['email']);
                $phone = trim($_POST['phone']);
                $dob = trim($_POST['dob']);
                $city = trim($_POST['city']);
                $state = trim($_POST['state']);
                $pincode = trim($_POST['pincode']);
                $address1 = trim($_POST['address1']);
                $address2 = trim($_POST['address2']);
                $id = trim($_POST['id']);
                $password = trim($_POST['password']);
                $role = trim($_POST['role']);

                // $insertResult = $this->inventoryModel->insertUserInfo($fullname, $email, $phone, $dob, $city, $state, $pincode, $address1, $address2, $id, $password, $role);
                $insertResult = $this->inventoryModel->insertUserInfo($fullname, $email, $phone, $dob, $city, $state, $pincode, $address1, $address2, $id, $password, $role, $imageName);


                // Check if insertion was successful
                if ($insertResult) {
                    // Insertion successful, set success message
                    $data['message'] = "User information added successfully.";
                } else {
                    // Insertion failed, set error message
                    $data['message'] = "Failed to add user information. Please try again.";
                }

                // Load the view with appropriate message
                $this->view('admin/userinfo', $data);
            } else if (isset($_POST['viewuserbtn'])) {
                $data = $this->inventoryModel->getAllUserView();
                $this->view('admin/viewuserprofile', $data);
            }
        }
    }


    public function editViewUser()
    {                             //Manage page
        $totalcount = trim($_POST['totalcount']);
        for ($count = 0; $count <= $totalcount; $count++) {
            if (isset($_POST['editbtn' . $count])) {
                $id = trim($_POST['id' . $count]);
                // echo  "id".$id;
                $data = $this->inventoryModel->getupdateUserView($id);
                // print_r($data);
                $this->view('admin/editviewuserprofile', $data);

            } else if (isset($_POST['deletebtn' . $count])) {
                $id = trim($_POST['id' . $count]);
                $data1 = $this->inventoryModel->deleteAllUserView($id);
                $aData['message'] = "deleted Successfully !!";
                $data = $this->inventoryModel->getAllUserView();
                $this->view('admin/viewuserprofile', $data, $aData);

            }
        }
    }

    public function updateViewUser()
    {                        //update page
        if (isset($_POST['save'])) {
            $id = trim($_POST['id']);
            $name = trim($_POST['name']);
            $email = trim($_POST['email']);
            $phone = trim($_POST['phone']);
            $dob = trim($_POST['dob']);
            $city = trim($_POST['city']);
            $state = trim($_POST['state']);
            $pincode = trim($_POST['pincode']);
            $address1 = trim($_POST['address1']);
            $address2 = trim($_POST['address2']);
            $role = trim($_POST['role']);

            $data1 = $this->inventoryModel->updateUserView($id, $name, $email, $phone, $dob, $city, $state, $pincode, $address1, $address2, $role);
            $data = $this->inventoryModel->getupdateUserView($id);
            $this->view('admin/editviewuserprofile', $data);


        } else if (isset($_POST['back'])) {
            $data = $this->inventoryModel->getAllUserView();
            $this->view('admin/viewuserprofile', $data);
        }

    }




    // add Product function
    public function addProduct()
    {
        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            // Sanitize input data
            $_POST = filter_input_array(INPUT_POST, FILTER_SANITIZE_STRING);

            // Initialize message variable
            $data['message'] = null;

            // Check if form is submitted
            if (isset($_POST['submit'])) {
                if (isset($_FILES['productImage']) && $_FILES['productImage']['error'] === UPLOAD_ERR_OK) {
                    $imageTmpName = $_FILES['productImage']['tmp_name'];
                    $imageName = $_FILES['productImage']['name'];

                    // Move the uploaded file to a permanent location
                    $uploadDirectory = 'uploads/'; // Specify the directory where you want to store uploaded images
                    $targetPath = $uploadDirectory . $imageName;

                    if (move_uploaded_file($imageTmpName, $targetPath)) {
                        // File uploaded successfully, store the path in the database or use it as needed
                        // You can save $targetPath in your database along with other user information
                        $data['message'] = "User image added successfully.";
                    } else {
                        // Failed to move the uploaded file, handle the error
                        $data['message'] = "Failed to add user image. Please try again.";
                    }
                }
                // Extract form data    
                $barcode = trim($_POST['barcode']);
                $pname = trim($_POST['pname']);
                $mfg = trim($_POST['mfg']);
                $qty = trim($_POST['qty']);
                $price = trim($_POST['price']);
                $mrp = trim($_POST['mrp']);
                $sales = trim($_POST['sales']);
                $category = trim($_POST['category']);

                $insertResult = $this->inventoryModel->insertAddProduct($barcode, $pname, $mfg, $qty, $price, $mrp, $sales, $category, $imageName);

                // Check if insertion was successful
                if ($insertResult) {
                    // Insertion successful, set success message
                    $data['message'] = "User information added successfully.";
                } else {
                    // Insertion failed, set error message
                    $data['message'] = "Failed to add user information. Please try again.";
                }

                // Load the view with appropriate message
                $this->view('admin/addproduct', $data);
            } else if (isset($_POST['update'])) {
                $data = $this->inventoryModel->getAllCategory();
                $this->view('admin/addproduct', $data);
            }
        }
    }

    // EDIT/UPDATE ADMIN PRODUCT INVENTORY
    public function editadminProductInv()
    {                             //Manage page
        $totalcount = trim($_POST['totalcount']);
        for ($count = 0; $count <= $totalcount; $count++) {
            if (isset($_POST['editbtn' . $count])) {
                $id = trim($_POST['id' . $count]);
                // echo  "id".$id;
                $data = $this->inventoryModel->getupdateadminProductInv($id);
                // print_r($data);
                $this->view('admin/editadminProductInv', $data);

            } else if (isset($_POST['deletebtn' . $count])) {
                $id = trim($_POST['id' . $count]);
                $data1 = $this->inventoryModel->deleteadminProductInv($id);
                $aData['message'] = "deleted Successfully !!";
                $data = $this->inventoryModel->getAllAdminProduct();
                $this->view('admin/admin_product_inventory', $data, $aData);

            }
        }
    }

    public function updateadminProductInv()
    {                        //update page
        if (isset($_POST['save'])) {
            $id = trim($_POST['id']);
            $name = trim($_POST['name']);
            $mrp = trim($_POST['mrp']);
            $sale_price = trim($_POST['sale_price']);
            $qty = trim($_POST['qty']);
            $mfg = trim($_POST['mfg']);
            $category = trim($_POST['category']);
            $price = trim($_POST['price']);
            // $address1 = trim($_POST['address1']);
            // $address2 = trim($_POST['address2']);
            // $role = trim($_POST['role']);

            $data1 = $this->inventoryModel->updateadminProductInv($id, $name, $mrp, $sale_price, $qty, $mfg, $category, $price);
            $data = $this->inventoryModel->getupdateadminProductInv($id);
            $this->view('admin/editadminProductInv', $data);


        } else if (isset($_POST['back'])) {
            $data = $this->inventoryModel->getAllAdminProduct();
            $this->view('admin/admin_product_inventory', $data);
        }

    }

    // addCategory

    public function addCategory()
    {
        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            // Sanitize input data
            $_POST = filter_input_array(INPUT_POST, FILTER_SANITIZE_STRING);

            // Initialize message variable
            $adata['message'] = null;

            // Check if form is submitted
            if (isset($_POST['submit'])) {
                // Extract form data    
                // $categoryid = trim($_POST['categoryid']);
                $nameInput = trim($_POST['name']);
                // echo "yuguyguy" . $nameInput;

                $id = $this->inventoryModel->insertAddCategory($nameInput);
                // $nameInput = "";

                // Check if insertion was successful
                if ($id) {
                    // Insertion successful, set success message
                    $adata['message'] = "User information added successfully.";
                } else {
                    // Insertion failed, set error message
                    $adata['message'] = "Failed to add user information. Please try again.";
                }
                $data = $this->inventoryModel->getAllCategory();
                // Load the view with appropriate message
                $this->view('admin/addcategory', $data, $adata);
            }
        }
    }


    public function editCategory()
    {                             //Manage page
        $totalcount = trim($_POST['totalcount']);
        for ($count = 0; $count <= $totalcount; $count++) {
            if (isset($_POST['editbtn' . $count])) {
                $id = trim($_POST['id' . $count]);
                // echo  "id".$id;
                $data = $this->inventoryModel->getupdateCategory($id);
                $this->view('admin/editcategory', $data);

            } else if (isset($_POST['deletebtn' . $count])) {
                $id = trim($_POST['id' . $count]);
                $data1 = $this->inventoryModel->deleteCategory($id);
                $aData['message'] = "deleted Successfully !!";
                $data = $this->inventoryModel->getAllCategory();
                $this->view('admin/addcategory', $data, $aData);

            }
        }
    }


    public function updateCategory()
    {                        //update page
        if (isset($_POST['save'])) {
            $id = trim($_POST['id']);
            $name = trim($_POST['name']);

            $data1 = $this->inventoryModel->updateCategory($id, $name);
            $data = $this->inventoryModel->getupdateCategory($id);
            $this->view('admin/editcategory', $data);


        } else if (isset($_POST['back'])) {
            $data = $this->inventoryModel->getAllCategory();
            $this->view('admin/addcategory', $data);
        }

    }

    // EDIT/UPDATE USER PRODUCT INVENTORY
    public function edituserProductInv()
    {                             //Manage page
        $totalcount = trim($_POST['totalcount']);
        for ($count = 0; $count <= $totalcount; $count++) {
            if (isset($_POST['editbtn' . $count])) {
                $id = trim($_POST['id' . $count]);
                // echo  "id".$id;
                $data = $this->inventoryModel->getupdateuserProductInv($id);
                // print_r($data);
                $this->view('inventorymanagement/edituserProductInv', $data);

            } else if (isset($_POST['deletebtn' . $count])) {
                $id = trim($_POST['id' . $count]);
                $data1 = $this->inventoryModel->deleteuserProductInv($id);
                $aData['message'] = "deleted Successfully !!";
                $data = $this->inventoryModel->getAllUserProduct();
                $this->view('inventorymanagement/product_inventory', $data, $aData);

            }
        }
    }

    public function updateuserProductInv()
    {                        //update page
        if (isset($_POST['save'])) {
            $id = trim($_POST['id']);
            $name = trim($_POST['name']);
            $mrp = trim($_POST['mrp']);
            $sale_price = trim($_POST['sale_price']);
            $qty = trim($_POST['qty']);
            $mfg = trim($_POST['mfg']);
            $category = trim($_POST['category']);

            $data1 = $this->inventoryModel->updateuserProductInv($id, $name, $mrp, $sale_price, $qty, $mfg, $category);
            $data = $this->inventoryModel->getupdateuserProductInv($id);
            $this->view('inventorymanagement/edituserProductInv', $data);


        } else if (isset($_POST['back'])) {
            $data = $this->inventoryModel->getAllUserProduct();
            $this->view('inventorymanagement/product_inventory', $data);
        }

    }


    // ADD BILL PRODUCT
    public function addcustomerdetails(){
        if (isset($_POST['save'])) {
            $customer_id = 'CUS'.mt_rand(10000,99999).mt_rand(10,99);
            $name = trim($_POST['name']);
            $phone = trim($_POST['phone']);
            $createdTs = $this->getCurrentTs();
            $createdBy = 'user';
            $id = $this->inventoryModel->addCustomerDetails($customer_id,$name,$phone,$createdTs,$createdBy);
            echo "WERFD".$id;
            $cust_id = $this->inventoryModel->idgetCustomerId($id);
            $data['customer_id'] = $cust_id->customer_id;
            $this->view('inventorymanagement/product_scan',$data);
        }
    }

    public function addBill(){
        if (isset($_POST['add'])) {
            $barcode = trim($_POST['barcode']);
            $customerId = trim($_POST['id']);
            $createdTs = $this->getCurrentTs();
            $createdBy = 'user';
            $data1 = $this->inventoryModel->getProductDetails($barcode);
            print_r($data1);
            $id = $this->inventoryModel->insertIntoBill($customerId,$data1->name,$data1->price,$data1->qty,$data1->sale_price,$createdTs,$createdBy);
            echo "dfghbjn".$data1->name;
            $data['customer_id'] = $customerId;
            $adata = $this->inventoryModel->getBillingProducts($customerId);
            $this->view('inventorymanagement/product_scan',$data,$adata);
        }
    }

    public function addBill1()
    {
        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            // Sanitize input data
            $_POST = filter_input_array(INPUT_POST, FILTER_SANITIZE_STRING);

            // Initialize message variable
            $adata['message'] = null;

            // Check if form is submitted
            if (isset($_POST['add'])) {
                // Extract form data    
                // $categoryid = trim($_POST['categoryid']);
                $name = trim($_POST['name']);
                $price = trim($_POST['price']);
                // echo "yuguyguy" . $nameInput;

                $id = $this->inventoryModel->insertBill($name, $price);
                // $nameInput = "";

                // Check if insertion was successful
                if ($id) {
                    // Insertion successful, set success message
                    $adata['message'] = "User information added successfully.";
                } else {
                    // Insertion failed, set error message
                    $adata['message'] = "Failed to add user information. Please try again.";
                }
                $data = $this->inventoryModel->getAllBill();
                // Load the view with appropriate message
                $this->view('iventorymanagement/product_scan', $data, $adata);
            }
        }else if (isset($_POST['newbtn'])) {
            // $data = $this->inventoryModel->getAllUserProduct();
            $this->view('inventorymanagement/product_scan');
        }
    }
  



    // *********************************
    public function uploadCarouselImage()
    {
        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            $_POST = filter_input_array(INPUT_POST, FILTER_SANITIZE_STRING);
            $data['message'] = null;
            if (isset($_POST['list'])) {
                $data = $this->inventoryModel->getAllSwipImage();
                $this->view('admin/image_swip_list', $data);
            } else if (isset($_POST['add_swiper'])) {
                $status = trim($_POST['status']);
                $createdTs = $this->getCurrentTs();
                $targetDir = "img/";
                $allowTypes = array('jpg', 'png', 'jpeg', 'avif');

                $statusMsg = $errorMsg = $insertValuesSQL = $errorUpload = $errorUploadType = '';
                $image = array_filter($_FILES['image']['name']);
                if (!empty($image)) {
                    foreach ($_FILES['image']['name'] as $key => $val) {
                        // File upload path 
                        $image = basename($_FILES['image']['name'][$key]);
                        $targetFilePath = $targetDir . $image;

                        // Check whether file type is valid 
                        $fileType = pathinfo($targetFilePath, PATHINFO_EXTENSION);
                        if (in_array($fileType, $allowTypes)) {
                            // Upload file to server 
                            if (move_uploaded_file($_FILES["image"]["tmp_name"][$key], $targetFilePath)) {
                                // Image db insert sql 
                                $insertValuesSQL .= "('" . $image . "', NOW()),";
                                $id = $this->inventoryModel->insertswiperimage($status, $image, $createdTs);
                                if ($id != null) {
                                    $data['message'] = "image is added Successfully !!";
                                } else {
                                    $data['message'] = "Failed to add data, please try again !!";
                                }
                            }
                        }
                    }
                }
                $this->view('admin/image_swip', $data);
            }
        }
    }

    public function editswiper()
    {
        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            $_POST = filter_input_array(INPUT_POST, FILTER_SANITIZE_STRING);
            $adata['message'] = null;
            $totalcount = trim($_POST['totalcount']);
            for ($count = 0; $count <= $totalcount; $count++) {
                if (isset($_POST['editbtn' . $count])) {
                    $Id = trim($_POST['id' . $count]);
                    $status = trim($_POST['status' . $count]);
                    $data1 = $this->inventoryModel->editSwipImage($Id, $status);
                    if ($data1 == true) {
                        $adata['message'] = "updated successfully";
                    }
                    $data = $this->inventoryModel->getAllSwipImage();
                    $this->view('admin/image_swip_list', $data, $adata);
                }
            }
        }
    }

    public function editgalleryimage()
    {
        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            $_POST = filter_input_array(INPUT_POST, FILTER_SANITIZE_STRING);
            $adata['message'] = null;
            $totalcount = trim($_POST['totalcount']);
            for ($count = 0; $count <= $totalcount; $count++) {
                if (isset($_POST['delete' . $count])) {
                    $Id = trim($_POST['id' . $count]);
                    $data1 = $this->inventoryModel->deleteGalleryImage($Id);
                    if ($data1 == true) {
                        $adata['message'] = "Image Deleted successfully";
                    }
                    $data = $this->inventoryModel->getAllGalleryImage();
                    $this->view('admin/image_gallery_list', $data, $adata);
                }
            }
        }
    }

    public function addnotice()
    {
        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            $_POST = filter_input_array(INPUT_POST, FILTER_SANITIZE_STRING);
            $data['message'] = null;
            if (isset($_POST['add_notice'])) {
                $notice = trim($_POST['notice']);
                $status = trim($_POST['status']);
                $createdTs = $this->getCurrentTs();
                $id = $this->inventoryModel->insertNoticeToDisplay($status, $notice, $createdTs);
                if ($id != null) {
                    $data['message'] = "Notice is added Successfully !!";
                }
                $this->view('admin/notice', $data);
            } else if (isset($_POST['list'])) {
                $data = $this->inventoryModel->getAllNotice();
                $this->view('admin/notice_list', $data);
            }
        }

    }

    public function editnotice()
    {
        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            $_POST = filter_input_array(INPUT_POST, FILTER_SANITIZE_STRING);
            $adata['message'] = null;
            $totalcount = trim($_POST['totalcount']);
            for ($count = 0; $count <= $totalcount; $count++) {
                if (isset($_POST['editbtn' . $count])) {
                    $Id = trim($_POST['id' . $count]);
                    $status = trim($_POST['status' . $count]);
                    // echo"eefdv".$status;
                    $data1 = $this->inventoryModel->editNoticeByStatus($Id, $status);
                    if ($data1 == true) {
                        $adata['message'] = "updated successfully";
                    }
                    $data = $this->inventoryModel->getAllNotice();
                    $this->view('admin/notice_list', $data, $adata);

                }
            }
        }
    }

    public function uploadGalleryImage()
    {
        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            $_POST = filter_input_array(INPUT_POST, FILTER_SANITIZE_STRING);
            $data['message'] = null;
            if (isset($_POST['list'])) {
                $data = $this->inventoryModel->getAllGalleryImage();
                $this->view('admin/image_gallery_list', $data);
            } else if (isset($_POST['add_image'])) {
                echo "arfnvfdcx";
                $createdTs = $this->getCurrentTs();
                $createdBy = 'admin';
                $targetDir = "uploads/";
                $allowTypes = array('jpg', 'png', 'jpeg', 'avif');
                $statusMsg = $errorMsg = $insertValuesSQL = $errorUpload = $errorUploadType = '';
                $image = array_filter($_FILES['image']['name']);
                echo "neha";
                if (!empty($image)) {
                    echo "erdgtfbv";
                    foreach ($_FILES['image']['name'] as $key => $val) {
                        // File upload path 
                        echo "werdgf";
                        $image = basename($_FILES['image']['name'][$key]);
                        $targetFilePath = $targetDir . $image;
                        echo "dewergtfh";
                        // Check whether file type is valid 
                        $fileType = pathinfo($targetFilePath, PATHINFO_EXTENSION);
                        print_r($fileType);
                        print_r($allowTypes);
                        if (in_array($fileType, $allowTypes)) {
                            // Upload file to server 
                            echo "erdtgfvc";
                            if (move_uploaded_file($_FILES["image"]["tmp_name"][$key], $targetFilePath)) {
                                // Image db insert sql 
                                $insertValuesSQL .= "('" . $image . "', NOW()),";
                                $id = $this->inventoryModel->insertgalleryimage($image, $createdTs, $createdBy);
                                if ($id != null) {
                                    $data['message'] = "image uploaded successfully !!";
                                } else {
                                    $data['message'] = "Failed to add data, please try again !!";
                                }
                            }
                        }
                    }
                }
                $this->view('admin/gallery', $data);
            }
        }
    }


    public function uploadachievementdata()
    {
        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            $_POST = filter_input_array(INPUT_POST, FILTER_SANITIZE_STRING);
            $data['message'] = null;
            if (isset($_POST['schoollist'])) {
                $data = $this->inventoryModel->getAllGalleryImage();
                $this->view('admin/school_achievements', $data);
            } else if (isset($_POST['studentlist'])) {
                $data = $this->inventoryModel->getAllGalleryImage();
                $this->view('admin/student_achievement', $data);
            } else if (isset($_POST['add_school_achievements'])) {
                $heading = trim($_POST['Heading']);
                $status = trim($_POST['status']);
                $createdTs = $this->getCurrentTs();
                $targetDir = "acheivement/";
                $allowTypes = array('jpg', 'png', 'jpeg', 'avif');
                $statusMsg = $errorMsg = $insertValuesSQL = $errorUpload = $errorUploadType = '';
                $image = array_filter($_FILES['image']['name']);
                if (!empty($image)) {
                    foreach ($_FILES['image']['name'] as $key => $val) {
                        // File upload path 
                        $image = basename($_FILES['image']['name'][$key]);
                        $targetFilePath = $targetDir . $image;
                        // Check whether file type is valid 
                        $fileType = pathinfo($targetFilePath, PATHINFO_EXTENSION);
                        if (in_array($fileType, $allowTypes)) {
                            // Upload file to server 
                            if (move_uploaded_file($_FILES["image"]["tmp_name"][$key], $targetFilePath)) {
                                // Image db insert sql 
                                $insertValuesSQL .= "('" . $image . "', NOW()),";
                                $id = $this->inventoryModel->insertSchoolAchievement($image, $heading, $createdTs);
                                if ($id != null) {
                                    $data['message'] = "image uploaded successfully !!";
                                } else {
                                    $data['message'] = "Failed to add data, please try again !!";
                                }
                            }
                        }
                    }
                }
                $this->view('admin/gallery', $data);
            }
        }
    }

    public function createUserSession($user, $uname)
    {
        session_start();
        // Taking current system Time
        $_SESSION['start'] = time();

        // Destroying session after 1 minute
        $_SESSION['expire'] = $_SESSION['start'] + (1 * 240);
        // echo " in session: userid is ". $user;
        $_SESSION['loggedin'] = "YES";
        $_SESSION['userid'] = $user;
        $_SESSION['username'] = $uname;

    }

    public function logout()
    {

        unset($_SESSION['userid']);
        unset($_SESSION['loggedin']);
        unset($_SESSION['username']);
        session_destroy();
    }



}
