<footer class=" text-center text-light" style="background:orange;font-family: 'Tenor Sans', sans-serif;">

  <!-- <section class=" p-2">
    <div class="container text-center text-md-start mt-5">

      <div class="row mt-3">
       
        <div class="col-md-2 col-lg-4 col-xl-3 text-center  mb-4">
         
         <img src="<?php echo URLROOT . "/img/logo.png"; ?>" height="200px" width="200px" alt="">
         <br>
         <span class="text-small ">Manjurmati High School<span>
        </div>
        <div class="col-md-2 col-lg-2 col-xl-2 mx-auto mb-4">
        
        </div>
       
        <div class="col-md-6 col-lg-4 col-xl-3  mb-md-0 mb-4">
        
          <h6 class="text-uppercase fw-bold mb-4">Contact</h6>
          <p><i class='bx bx-home'></i> &nbsp; CMM9+24M, Lohardaga,Jharkhand 835302</p>
          
          <p>
          <i class='bx bx-envelope'></i> &nbsp;
    gmail@gmail.com 
          </p>
          <p><i class='bx bxs-phone'></i> &nbsp; + 2332111190
</p> 
        </div>
      </div>
     
    </div>
  </section> -->
  <!-- Grid container -->

  <!-- Copyright -->
  <div class="text-center p-4  " style="background-color: rgba(0, 0, 0, 0.2);">
  © 2023 All rights are reserved this website is designed by:
    <a class="text-reset fw-bold" href="https://pentahead.in/">PentaHead</a>
  </div>

</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script> 
</body>
</html>