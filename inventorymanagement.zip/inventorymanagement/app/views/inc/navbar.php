<!-- Nav section-->
<?php require APPROOT . '/views/inc/header.php'; ?>

<form action="<?php echo URLROOT; ?>iventorys/navForm" method="post">
<nav class="navbar navbar-expand-lg" style="background: rgb(131, 37, 194);
        background: linear-gradient(
          90deg,
          rgba(131, 37, 194, 1) 0%,
          rgba(85, 153, 194, 1) 78%
        );box-shadow: 0px 20px 32px 0px rgb(179, 180, 181); padding:18px;">
      <div class="container-fluid">
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarTogglerDemo01"aria-controls="navbarTogglerDemo01"aria-expanded="false"aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarTogglerDemo01">
          <a class="navbar-brand" href="#" style="color: azure">
            <img src="increase.png" alt="" height="40px" width="auto" />company logo</a>
            <ul class="navbar-nav me-auto mb-2 mb-lg-0 px-5">
              <li class="nav-item">
                <button id="dashboard" name="dashboard" class="nav-link active btn" aria-current="page" href="#" style="color: white;font-size:18px; border:none;">Dashboard</button>
              </li>
              <li class="nav-item">
                <button id="product_scan" name="product_scan" class="nav-link btn" href="#" style="color: white;font-size:18px;border:none;">Product Scanner</button>
              </li>
              <li class="nav-item">
                <button id="product_inventory" name="product_inventory" class="nav-link btn" href="#" style="color: white;font-size:18px">Product Inventory</button>
              </li>
              <li class="nav-item">
                <button id="invoice" name="invoice" class="nav-link btn" href="#" style="color: white;font-size:18px; border:none;">Invoice</button>
              </li>
            </ul>
          <!--image profile-->
          <button id="userviewprofile" name="userviewprofile" class="btn me-3" style="display: flex;align-items: center;
          background: #f5f6fa;border: 2px solid #efeef1;border-radius: 6px;height: 50px;width: 170px;padding: 0 15px 0 2px;">
              <img src="<?php echo URLROOT . "/img/profile-img.jpg"; ?>" alt="" style="height: 40px;width: 40px;border-radius: 6px;object-fit: cover;"/>
              <span class="admin_name" style="font-size: 15px;font-weight: 500;color: #333;margin: 0 10px;white-space: nowrap;">User Name</span>
            </button>
          <form class="d-flex" role="search">
            <input class="form-control me-2" type="search" placeholder="Search" aria-label="Search" style="width:200px"/>
            <button class=" me-2 btn" style="color: white; border: 2px solid #1fd655;" type="submit">Search</button>
          </form>
          <button style="border:none;background:none;"><img src="<?php echo URLROOT . "/img/power.png"; ?>" alt="" style="height: 30px;width: auto;"/> </button>
          
        </div>
      </div>
    </nav>
   
</form>