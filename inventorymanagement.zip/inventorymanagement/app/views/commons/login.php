<?php require APPROOT . '/views/inc/header.php'; ?>
<style>
    /* @import url("https://fonts.googleapis.com/css2?family=Open+Sans:wght@200;300;400;500;600;700&display=swap"); */

        * {
          margin: 0;
          padding: 0;
          box-sizing: border-box;
          font-family: "Open Sans", sans-serif;
        }
        
        /* body {
          display: flex;
          align-items: center;
          justify-content: center;
          min-height: 100vh;
          width: 100%;
          padding: 0 10px;
        } */
        
        body::before {
          content: "";
          position: absolute;
          width: 100%;
          height: 100%;
          background: url(https://i.pinimg.com/originals/f5/43/d7/f543d74332fae1e0fe2cd64f9c0ea2fb.jpg), #000000;
          background-position: center;
          background-size: cover;
        }
        
        .wrapper {
          width: 400px;
          border-radius: 8px;
          padding: 30px;
          text-align: center;
          border: 3px solid white;
          backdrop-filter: blur(50px);
          -webkit-backdrop-filter: blur(9px);
        }
        
        /* form {
          display: flex;
          flex-direction: column;
        } */
        
        h2 {
          font-size: 2rem;
          margin-bottom: 20px;
          color: white;
        }
        
        .input-field {
          position: relative;
          border-bottom: 2px solid white;
          margin: 15px 0;
        }
        
        .input-field label {
          position: absolute;
          top: 50%;
          left: 0;
          transform: translateY(-50%);
          color: white;
          font-size: 16px;
          pointer-events: none;
          transition: 0.15s ease;
        }
        
        .input-field input {
          width: 100%;
          height: 40px;
          background: transparent;
          border: none;
          outline: none;
          font-size: 16px;
          color:white;
        }
        
        .input-field input:focus~label,
        .input-field input:valid~label {
          font-size: 0.8rem;
          top: 10px;
          transform: translateY(-120%);
        }
        
        /* .wrapper a:hover {
          text-decoration: underline;
        }
        
        
        button:hover {
          color: #fff;
          border-color: #fff;
          background: rgba(255, 255, 255, 0.15);
        } */
        
        </style>
        <form class="row justify-content-center" action="<?php echo URLROOT; ?>commons/adminlogindetails" method="post" enctype="multipart/form-data">
        <div class="wrapper mt-5">
          <h2>Login Here!!</h2>
          <div class="input-field">
          <input id="login_id" name="login_id" style="width: 100%;height: 40px;background: transparent;border: none;outline: none;font-size: 16px;color:white;" type="text" >
          <label>Enter your email</label>
        </div>
        <?php
        if ($data == 'password_mismatch') {
          echo "Invalid Username/Password, Please try again ! ";
        } else {
          //  echo "logged in";
        }
        ?>
        <div class="input-field">
          <input id="password" name="password" style="width: 100%;height: 40px;background: transparent;border: none;outline: none;font-size: 16px;color:white;" type="password" >
          <label>Enter your password</label>
        </div>
        <div class="col-sm-12 mt-3">
              <select class="form-select" aria-label="Default select example" id="role" name="role">
                <option selected>Open this select menu</option>
                <option value="Admin">Admin</option>
                <option value="User">User</option>
              </select>
            </div>
            <div class="forget" style=" display: flex;align-items: center;justify-content: space-between;margin: 25px 0 35px 0;color:white;">
            <!-- <label style="display: flex;align-items: center;" for="remember">
            <input type="checkbox" id="remember" style="accent-color: white;">
            <p style=" margin-left: 8px;">Remember me</p>
          </label> -->
          <a style="color: white;text-decoration: none;" href="#">Forgot password?</a>
        </div>

        <button class="mt-4" id="loginbtn" name="loginbtn" style=" background: #fff;color: #000;font-weight:600;border:none;padding:12px 20px;
        cursor: pointer;border-radius: 3px;font-size: 16px;border: 2px solid transparent;transition: 0.3s ease;" type="submit">Log In</button>
          <div class="col-12">
            <span style="color:white">Don't have an account?</span>
            <button id="registerbtn" name="registerbtn" type="submit" class="btn" style="color:white;"><u>Register</u></button>
          </div>
        </div>
</form>