<?php require APPROOT . '/views/inc/header.php'; ?>
  <style>
        .absolute{
            position: absolute;
            top: 50px !important;
            inset: 0;
            justify-content: center;
            display: inline-flex;
            flex-direction: row;
        }

        .bg-shape1{
            width: 400px;
            height: 450px;
            border-radius: 9999px;
            position: relative;
            animation: one 10s infinite;
        }

        .bg-shape2{
            width: 300px;
            height: 450px;
            border-radius: 9999px;
            position: relative;
            animation: two 10s infinite;
        }

        .opacity-50{
            opacity: 0.5;
        }

        .bg-blur{
            filter: blur(90px);
        }

        .card {
            background-color: rgba(255, 255, 255, 0.15); 
            backdrop-filter: blur(10px); 
            border-radius: 20px; 
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1), 0 1px 3px rgba(0, 0, 0, 0.08); 
        }

        .form-control {
            background-color: transparent; 
            border-color: rgba(255, 255, 255, 0.3); 
            color: #fff;
        }

        .bg-primary{
            background-color: rgb(30,0,255);
        }

        .bg-teal{
            background-color: rgb(255, 72, 173);
        }

        .bg-purple {
            background-color: rgb(159, 9, 240);
        }
       
    </style>
<form class="row" action="<?php echo URLROOT; ?>inventorys/adminRegister" method="post"  enctype="multipart/form-data">
    <div class=" container mt-5">
        <!-- <div class="card" style="border: none;"> -->
          <div class="absolute">
            <div class="absolute inset-0 justify-center">
                <div class="bg-shape1 bg-teal opacity-50 bg-blur"></div>
                <div class="bg-shape2 bg-primary opacity-50 bg-blur"></div>
                <div class="bg-shape1 bg-purple opacity-50 bg-blur"></div>
            </div>
           
        </div>
            <div class="row justify-content-center">
                <center><h1>Registration Form</h1>
                    <p>Fill out the form carefully for registration</p></center>
                
                
                <div class="col-sm-10">
                  <div class="card mb-3 ms-3 me-3" style="border: none;">
                    <div class="card-body">
                      
                      
                        <div class="row">
                        <div class="col-md-4">
                          <label for="name" class="form-label">Full Name</label>
                          <input id="name" name="name" style="border: 1px solid white;" type="text" class="form-control"  >
                        </div>
                       
                        <div class="col-md-4">
                          <label for="email" class="form-label">Email Id</label>
                          <!-- <div class="input-group has-validation"> -->
                            <!-- <span class="input-group-text" id="inputGroupPrepend">@</span> -->
                            <input id="email" name="email" style="border: 1px solid white;" type="text" class="form-control"  >
                            
                          <!-- </div> -->
                        </div>
                        <div class="col-md-4">
                            <label for="password" class="form-label">Password</label>
                            <input id="password" name="password" style="border: 1px solid white;" type="password" class="form-control"  >
                           
                          </div>
      </div>
                        <div class="row">
                        <div class="col-md-4">
                          <label for="city" class="form-label">City</label>
                          <input id="city" name="city" style="border: 1px solid white;" type="text" class="form-control"  >
                          
                        </div>
                        <div class="col-md-4">
                            <label for="state" class="form-label">State</label>
                            <input id="state" name="state" style="border: 1px solid white;" type="text" class="form-control"  >
                            
                          </div>
                        <div class="col-md-4">
                          <label for="zip_code" class="form-label">Zip Code</label>
                          <input id="zip_code" name="zip_code" style="border: 1px solid white;" type="text" class="form-control" >
                          
                        </div>
      </div>
                        <div class="row">
                        <div class="col-md-4">
                            <label for="phone" class="form-label">Phone No.</label>
                            <input id="phone" name="phone" style="border: 1px solid white;" type="text" class="form-control" >
                            
                          </div>
                          <div class="col-md-4">
                            <label for="dob" class="form-label">DOB</label>
                            <input id="dob" name="dob" style="border: 1px solid white;" type="date" class="form-control" >
                            
                          </div>
                          <div class="col-md-4">
                            <label id="role" name="role" for="role" class="form-label">Role</label>
                            <select id="role" name="role" class="form-select" >
                              <option selected disabled value="">Choose...</option>
                              <option>Admin</option>
                              <option>User</option>
                            </select>
                            <!-- <div class="invalid-feedback">
                              Please select a valid state.
                            </div> -->
                          </div>
      </div>
                          <div class="row">
                          <div class="col-md-8">
                            <label for="address" class="form-label">Address</label>
                            <input id="address" name="address" style="border: 2px solid white;" type="textarea" class="form-control" >
                            
                          </div>
                          <div class="col-md-4">
                            <label for="image" class="form-label">Add your image</label>
                            <input  style="border: 1px solid white;" type="file" class="form-control" id="image[]" name="image[]" accept="image/*">
                          </div>
      </div>
                        
                        <div class="col-12 mt-3">
                          <button id="submit" name="submit" class="btn btn-primary" type="submit">Submit form</button>
                        </div>

                        <div class="col-12">
                          <span>Already have an account?</span>
                          <button id="loginbtn" name="loginbtn" type="submit" class="btn" style="border: 2px solid rgb(123, 123, 229);">Login</button>
                        </div>
                      <!-- </form> -->
                    </div>
                  </div>
                </div>
              </div>
        </div>
    </div>
      </form>
    <!-- </div> -->

