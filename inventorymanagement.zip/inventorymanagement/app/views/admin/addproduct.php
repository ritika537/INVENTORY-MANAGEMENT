<?php require APPROOT . '/views/inc/header.php'; ?>
<?php require APPROOT . '/views/inc/adminnavbar.php'; ?>

<form action="<?php echo URLROOT; ?>inventorys/addProduct" method="post" enctype="multipart/form-data">
<div class="container">
  <h1 class="text-center mt-4 mb-5" style="color: rgb(111, 111, 234)"><b>ADD PRODUCTS</b></h1>
  <div class="row">
    <!-- Add Product Card -->
    <div class="col-sm-12 mb-4">
      <div class="card" style="box-shadow: 10px 25px 32px 0px rgb(179, 180, 181);">
      <div class="card-header  text-white" style="background-color: rgb(111, 111, 234);"><b>Add Product</b>
      <button type="submit" class="btn" id="update" class="update" style="color:white; border:1px solid white; ">Update category</button>
    </div>
      <!-- <button>Update category</button> -->
      <div class="card-body">
        <form id="addProductForm">
          <div class="row">
            <div class="col-sm-4">
              <label for="barcode" class="form-label">BARCODE</label>
              <input type="text" class="form-control" id="barcode" name="barcode" />
            </div>
            <div class="col-sm-4">
              <label for="pname" class="form-label">PRODUCT NAME</label>
              <input type="text" class="form-control" id="pname" name="pname" />
            </div>
            <div class="col-sm-4">
              <label for="profileImage" class="form-label">Product Image</label>
              <input type="file" class="form-control" id="productImage" name="productImage" accept="image/*">
            </div>
          </div>
          <div class="row g-3">
            <div class="col-sm-4">
              <label for="category" id="category" name="category">CATEGORY</label>
              <select class="form-select mt-2" id="category" name="category">
                <option>--select category--</option>
                <!-- <button class="btn">reload</button> -->
                <option>ELECTRONICS</option>
                <option>CLOTHES</option>
                <option>COSMETICS</option>
              </select>
            </div>
            <div class="col-sm-4">
              <label for="manu" class="form-label">MANUFACTURER</label>
              <input type="text" class="form-control" id="mfg" name="mfg" />
            </div>
            <div class="col-sm-4">
              <label for="availableQuantity" class="form-label">QUANTITY</label>
              <input type="number" class="form-control" id="qty" name="qty" />
            </div>
          </div>
          <div class="row">
            <div class="col-md-4">
              <label for="pp" class="form-label">PURCHASE PRICE</label>
              <input type="number" class="form-control" id="price" name="price" />
            </div>
            <div class="col-md-4">
              <label for="mrp" class="form-label">MRP</label>
              <input type="number" class="form-control" id="mrp" name="mrp" />
            </div>
            <div class="col-md-4">
              <label for="sp" class="form-label">SALE PRICE</label>
              <input type="number" class="form-control" id="sales" name="sales" />
            </div>
          </div>
          <button id="submit" name="submit" type="submit" class="btn mt-3" style="background-color: rgb(111, 111, 234);color: white;">Submit</button>
        </form>
      </div>
    </div>
  </div>
</div>
</div>
</form>


