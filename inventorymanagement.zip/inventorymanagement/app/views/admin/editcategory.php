<?php require APPROOT . '/views/inc/header.php'; ?>
<?php require APPROOT . '/views/inc/adminnavbar.php'; ?>

<form action="<?php echo URLROOT; ?>inventorys/updateCategory" method="post">
<input type ="hidden" id="id" name="id" value="<?php echo $data->id; ?>">
    <div class="container">
        <h1 class="text-center mt-4 mb-5" style="color: rgb(111, 111, 234)"><b>EDIT CATEGORY</b></h1>
        <div id="formContainer">
            <label style="display: block; margin-top: 10px;" for="nameInput"> Category Name: </label>
            <input style="width: 300px; padding: 8px; margin-top: 5px; border: 1px solid #ccc; border-radius: 4px;" type="text" 
            id="name" name="name" placeholder="Enter your name" value="<?php echo $data->name; ?>">
            <button type="submit" id="save" name="save" style=" margin: 10px; padding: 8px 16px; background-color: rgb(111, 111, 234); 
            color: #fff; border: none; border-radius: 4px; cursor: pointer;">Save</button>
            <button type="submit" id="back" name="back" style=" margin: 10px; padding: 8px 16px; background-color: rgb(111, 111, 234); 
            color: #fff; border: none; border-radius: 4px; cursor: pointer;">Back</button>
        </div>
    </div>
</form>

