<?php require APPROOT . '/views/inc/header.php'; ?>
<?php require APPROOT . '/views/inc/adminnavbar.php'; ?>


<form action="<?php echo URLROOT; ?>inventorys/addCategory" method="post" enctype="multipart/form-data">

<div class="container">
<h1 class="text-center mt-4 mb-5" style="color: rgb(111, 111, 234)"><b>ADD CATEGORY</b></h1>
<!-- <div id="formContainer">  -->
<label style="display: block; margin-top: 10px;" for="emailInput"> Category Id: </label> 
        <input style="width: 300px; padding: 8px; margin-top: 5px; border: 1px solid #ccc; border-radius: 4px;" type="text" 
               id="categoryid" name="categoryid"
               placeholder="Enter your id"> 
        <label style="display: block; margin-top: 10px;" for="nameInput"> Category Name: </label> 
        <input style="width: 300px; padding: 8px; margin-top: 5px; border: 1px solid #ccc; border-radius: 4px;" type="text" 
               id="name" name="name" placeholder="Enter your name"> 
        
      
        <button id="submit" name="submit" type="submit" style=" margin: 10px; padding: 8px 16px; background-color: rgb(111, 111, 234); color: #fff; border: none; border-radius: 4px; cursor: pointer;" > 
              Add 
          </button> 
    <!-- </div>  -->
</form>

<form  action="<?php echo URLROOT; ?>inventorys/editCategory" method="post">
    <table class="table table-responsive table-hover table-sm mt-5">
                <thead>
                <tr>
                  <th scope="col">SN</th>
                  <th scope="col">Category Name</th>
                  <!-- <th scope="col">Project Name</th> --> 
                  <th scope="col"></th>
                </tr>
                </thead>
                <tbody>
               <?php $count = 0;
               foreach ($data as $dataline) { {
                   echo '<tr>'; ?>
                   <!-- <input type="hidden" value="<?php echo $dataline->id; ?>" name="<?php echo 'id' . $count; ?>"> -->
                   <input type ="hidden" name="<?php echo 'id'.$count; ?>" value="<?php echo $dataline->id; ?>">
                   <input type ="hidden" name="<?php echo 'name'.$count; ?>" value="<?php echo $dataline->name; ?>">
                   <th scope="row"><?php echo $count + 1; ?></th>
                   <td><?php echo $dataline->name; ?></td>
                   <td>
                    <button style="border:none;" type="submit" id="<?php echo 'editbtn'.$count; ?>" name="<?php echo 'editbtn'.$count; ?>" value="<?php echo $dataline->id; ?>"><img src="<?php echo URLROOT . '/img/icons8-pencil-50.png'; ?>" alt="se" height="30px"></button>
                    <button style="border:none;" type="submit" id="<?php echo 'deletebtn'.$count; ?>" name="<?php echo 'deletebtn'.$count; ?>" value="<?php echo $dataline->id; ?>"><img src="<?php echo URLROOT . '/img/delete.png'; ?>" alt="se" height="30px"></button>
                  </td> 
  <?php echo '</tr>';} ?>
  <?php $count++;} ?>  
  <input type="hidden" value="<?php echo $count;?>" name="totalcount" id="totalcount">
  <!-- <?php echo $count;?> -->
                              </tbody>
                            </table>
                          </div>
</form>





