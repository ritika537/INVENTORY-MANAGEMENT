<?php require APPROOT . '/views/inc/header.php'; ?>
<?php require APPROOT . '/views/inc/adminnavbar.php'; ?>
<form action="<?php echo URLROOT; ?>inventorys/editViewUser" method="post" enctype="multipart/form-data">

    <div class="container mt-3">
        <div class="row">
            <div class="col-md-12">
            <h1 class="mt-2 mb-5" style="color: rgb(111, 111, 234)"><b>USER INFORMATION</b></h1>
            </div>
            <?php $count = 0;
            foreach ($data as $dataline) {
                if ($count % 4 == 0) {
                    echo '<div class="row">';
                } ?>
                    <input type="hidden" value="<?php echo $dataline->id; ?>" name="<?php echo 'id' . $count; ?>">
                    <div class="col-sm-3 my-3 ">
                        <div class="card h-100"  style="border: none;box-shadow: 0px 20px 32px 0px rgb(179, 180, 181);">
                        <div class="card-body">
                        
                            <img src="<?php echo URLROOT . 'uploads/' . $dataline->image; ?>" class="image-fluid" height="250px" width="260px" alt="">
                            <!-- <h3 style="text-align:center"><?php echo $dataline->name; ?></h3> -->
                            <h4 class="card-title"><?php echo $dataline->name; ?></h4>
                            <h6><b>Email Id:</b> <?php echo $dataline->email; ?></h6>
                            <h6><b>Phone:</b> <?php echo $dataline->phone; ?></h6>
                            <h6><b>Role:</b> <?php echo $dataline->role; ?></h6>
                            <h6><b>DOB: </b><?php echo $dataline->dob; ?></h6>
                            <h6><b>City: </b><?php echo $dataline->city; ?></h6>
                            <h6><b>State:</b> <?php echo $dataline->state; ?></h6>
                            <h6><b>Pincode:</b> <?php echo $dataline->pincode; ?></h6>
                            <h6><b>Address:</b> <?php echo $dataline->address1; ?></h6>
                            <input type="hidden" value="<?php echo $dataline->subcategory_type; ?>" name="<?php echo 'subcategory_type' . $count; ?>">
                            <div class="row">
                                <div class="col-sm-6">
                                <button style="border:none;" type="submit" id="<?php echo 'editbtn' . $count; ?>" name="<?php echo 'editbtn' . $count; ?>"><img src="<?php echo URLROOT . '/img/icons8-pencil-50.png'; ?>" alt="..." height="30px"></button>
                                <button style="border:none;" type="submit" id="<?php echo 'deletebtn' . $count; ?>" name="<?php echo 'deletebtn' . $count; ?>" ><img src="<?php echo URLROOT . '/img/delete.png'; ?>" alt="..." height="30px"></button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <?php '</div>' ?>
            <?php $count++;
            } ?> 
    <input type="hidden" value="<?php echo $count; ?>" name="totalcount" id="totalcount">
</div>
</div>
    </div><!----conatiner band----->
</form>





