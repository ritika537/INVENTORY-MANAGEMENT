<?php require APPROOT . '/views/inc/header.php'; ?>
<?php require APPROOT . '/views/inc/adminnavbar.php'; ?>
<form action="<?php echo URLROOT; ?>inventorys/editadminProductInv" method="post" enctype="multipart/form-data">

    <div class="container mt-3">
        <div class="row">
            <div class="col-md-12">
            <h1 class="mt-2 mb-5" style="color: rgb(111, 111, 234)"><b>PRODUCT INVENTORY</b></h1>
            </div>
            <?php $count = 0;
            foreach ($data as $dataline) {
                if ($count % 4 == 0) {
                    echo '<div class="row">';
                } ?>
                        <input type="hidden" value="<?php echo $dataline->id; ?>" name="<?php echo 'id' . $count; ?>">
                            <div class="col-sm-3 my-3 ">
                                    <div class="card h-100" style="padding:0px; border: none;box-shadow: 0px 20px 32px 0px rgb(179, 180, 181);">
                                <div class="card-body">
                                <img src="<?php echo URLROOT . 'uploads/' . $dataline->image; ?>" class="image-fluid" height="250px" width="260px" alt="">
                                    <!-- <h3 style="text-align:center"><?php echo $dataline->name; ?></h3> -->
                                    <h4 class="card-title"><?php echo $dataline->name; ?></h4>
                                    <h6><b>BarCode:</b> <?php echo $dataline->bar_code; ?></h6>
                                    <h6><b>Mfg:</b> <?php echo $dataline->mfg; ?></h6>
                                    <h6><b>Category:</b> <?php echo $dataline->category; ?></h6>
                                    <h6><b>Mrp: </b><?php echo $dataline->mrp; ?></h6>
                                    <h6><b>Purchase Price: </b><?php echo $dataline->price; ?></h6>
                                    <h6><b>Sales Price:</b> <?php echo $dataline->sale_price; ?></h6>
                                    <h6><b>Qunatity:</b> <?php echo $dataline->qty; ?></h6>
                                    <input type="hidden" value="<?php echo $dataline->subcategory_type; ?>" name="<?php echo 'subcategory_type' . $count; ?>">
                                    <!-- <button class="btn " style="color:white;background:#6c89b4;width:100%"  id="<?php echo 'shop' . $count; ?>" name="<?php echo 'shop' . $count; ?>">Shop Now</button> -->
                                    <div class="row">
                                        <div class="col-sm-6">
                                            <button style="border:none;" type="submit" id="<?php echo 'editbtn' . $count; ?>" name="<?php echo 'editbtn' . $count; ?>"><img src="<?php echo URLROOT . '/img/icons8-pencil-50.png'; ?>" alt="..." height="30px"></button>
                                            <button style="border:none;" type="submit" id="<?php echo 'deletebtn' . $count; ?>" name="<?php echo 'deletebtn' . $count; ?>" ><img src="<?php echo URLROOT . '/img/delete.png'; ?>" alt="..." height="30px"></button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <?php '</div>' ?>
                        <?php $count++;

            } ?> 
             
               <input type="hidden" value="<?php echo $count; ?>" name="totalcount" id="totalcount">
               
             
        </div>
        </div>


    </div><!----conatiner band----->
</form>
</div>
</div>

</div>
<div class="row">
    <div class="col-sm-12">
        <?php require APPROOT . '/views/inc/footer.php'; ?>
    </div>
</div>