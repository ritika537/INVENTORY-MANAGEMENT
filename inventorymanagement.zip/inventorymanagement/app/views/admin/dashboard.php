<?php require APPROOT . '/views/inc/header.php'; ?>
<?php require APPROOT . '/views/inc/adminnavbar.php'; ?>


<form action="<?php echo URLROOT; ?>inventorys/uploaddashboard" method="post" enctype="multipart/form-data">
  <div class="container mt-5">
      <div class="row">
      <h1 class="mt-4 mb-5" style="color: rgb(111, 111, 234)"><b>ADMIN PANEL</b></h1>
      </div>
      <div class="row">
        <!-- <h2>Admin Panel</h2> -->
        <div class="col-sm-3">
          <div class="card h-100" style="background: rgb(166, 105, 189);
              background: linear-gradient(
                90deg,
                rgba(166, 105, 189, 1) 0%,
                rgba(166, 212, 206, 0.70640756302521) 100%
              );
              border: none;box-shadow: 0px 20px 32px 0px rgb(179, 180, 181);">
            <div class="card-body" style="color: white">
            <div class="card-title" style="font-weight: 700">
            <img src="<?php echo URLROOT . "/img/cart.png"; ?>" height="40px" weight="40px" /> INVENTORY
          </div>
          <h1 class="text-center">399</h1>
          <p class="card-text text-center">+45% from previous month</p>
        </div>
      </div>
    </div>
    <div class="col-sm-3">
      <div class="card h-100" style="background: rgb(234, 47, 38);
              background: linear-gradient(
                90deg,
                rgba(234, 47, 38, 1) 0%,
                rgba(217, 140, 22, 0.70640756302521) 100%
              );border: none;box-shadow: 0px 20px 32px 0px rgb(179, 180, 181);">
              <div class="card-body" style="color: white">
              <div class="card-title" style="font-weight: 700">
                <img src="<?php echo URLROOT . "/img/increase.png"; ?>" height="40px" weight="40px" /> SALES
              </div>
              <h1 class="text-center">RS 10,000</h1>
              <p class="card-text text-center">Total Sales</p>
            </div>
          </div>
        </div>
        <div class="col-sm-3">
          <div class="card h-100" style="background: rgb(78, 234, 38);
              background: linear-gradient(
                90deg,
                rgba(78, 234, 38, 1) 0%,
                rgba(238, 220, 194, 0.70640756302521) 100%
              );
              border: none;box-shadow: 0px 20px 32px 0px rgb(179, 180, 181);">
              <div class="card-body" style="color: white">
              <div class="card-title" style="font-weight: 700">
              <img src="<?php echo URLROOT . "/img/box.png"; ?>" height="40px" weight="40px" /> PRODUCTS
            </div>
            <h1 class="text-center">150</h1>
            <p class="card-text text-center">Total Product</p>
          </div>
        </div>
      </div>
      <div class="col-sm-3">
        <div class="card h-100" style="background: rgb(202, 38, 234);
        background: linear-gradient(
                90deg,
                rgba(202, 38, 234, 1) 0%,
                rgba(229, 132, 211, 0.70640756302521) 100%
              );border: none;box-shadow: 0px 20px 32px 0px rgb(179, 180, 181);">
              <div class="card-body" style="color: white">
              <div class="card-title" style="font-weight: 700">
              <img src="<?php echo URLROOT . "/img/new-account.png"; ?>" height="40px" weight="40px" />
                CUSTOMERS
              </div>
              <h1 class="text-center">2</h1>
              <p class="card-text text-center">Cashier</p>
            </div>
          </div>
        </div>
      </div>
    </div>
</form>