<?php require APPROOT . '/views/inc/header.php'; ?>
<?php require APPROOT . '/views/inc/adminnavbar.php'; ?>

<form action="<?php echo URLROOT; ?>inventorys/userInfo" method="post" enctype="multipart/form-data">
<div class="container">
  <div class="row">
    <div class="col-sm-10">
    <h1 class=" mt-5 mb-5" style="color: rgb(111, 111, 234)"><b>ADD USER INFORMATION</b></h1>
</div>
<div class="col-sm-2">
    <button type="submit" id="viewuserbtn" name="viewuserbtn"  class=" mt-5 mb-5 btn" style="background-color: rgb(111, 111, 234);color: white;">View All Users</button>
</div>
</div>
  <div class="row">
    <!-- Add Product Card -->
    <div class="col-md-12 mb-4">
      <div class="card" style="box-shadow: 10px 25px 32px 0px rgb(179, 180, 181);">
        <div class="card-header  text-white" style="background-color: rgb(111, 111, 234);">User Details</div>
        <div class="card-body">
          <form id="addProductForm">
            <!-- Personal Details -->
            <div class="row">
              <h3>Personal Details</h3>
            </div>
            <div class="row">
              <div class="col-sm-3">
                <label for="titleDropdown" class="form-label">Title</label>
                <select class="form-select" id="titleDropdown" name="titleDropdown">
                  <option value="Select">Select Title</option>
                  <option value="mr">Mr.</option>
                  <option value="mrs">Mrs.</option>
                  <option value="ms">Ms.</option>
                </select>
              </div>
              <div class="col-sm-3">
                <label for="fullname" class="form-label">Full Name</label>
                <input type="text" class="form-control" id="fullname" name="fullname" />
              </div>
              <div class="col-sm-3">
                <label for="profileImage" class="form-label">Profile Image</label>
                <!-- <input type="file" class="form-control" id="profileImage" name="profileImage" accept="image/*" onchange="previewImage(event)"> -->
                <input type="file" class="form-control" id="profileImage" name="profileImage" accept="image/*">
              </div>
              <div class="col-sm-3">
                <img id="imagePreview" src="#" alt="Preview Image" style="max-width: 100%; height: auto; display: none;" >
              </div>
            </div>
            <div class="row">
              <div class="col-sm-3">
                <label for="email" class="form-label">Email Address</label>
                <input type="text" class="form-control" id="email" name="email" />
              </div>
              <div class="col-sm-3">
                <label for="phone" class="form-label">Phone Number</label>
                <input type="text" class="form-control" id="phone" name="phone" />
              </div>
              <div class="col-sm-3">
                <label for="dob" class="form-label">DOB</label>
                <input type="date" class="form-control" id="dob" name="dob" /> 
              </div>
              <div class="col-sm-3">
                <label for="city" class="form-label">City</label>
                <input type="text" class="form-control" id="city" name="city" />
              </div>
            </div>
            <div class="row">
              <div class="col-sm-3">
                <label for="state" class="form-label">State</label>
                <input type="text" class="form-control" id="state"  name="state"/>
              </div>
              <div class="col-sm-3">
                <label for="pincode" class="form-label">Pincode</label>
                <input type="text" class="form-control" id="pincode" name="pincode" />
              </div>
              <div class="col-sm-3">
                <label for="address1" class="form-label">Address 1</label>
                <input type="text" class="form-control" id="address1" name="address1"/>
              </div>
              <div class="col-sm-3">
                <label for="address2" class="form-label">Address 2</label>
                <input type="text" class="form-control" id="address2" name="address2" />
              </div>
            </div>
            <!-- System Details -->
            <hr style="border: 1px solid black">
            <div class="row mt-3">
              <h3>System Details</h3>
            </div>
            <div class="row">
              <div class="col-sm-4">
                <label for="systemid" class="form-label">System Id</label>
                <input type="text" class="form-control" id="id" name="id" />
              </div>
              <div class="col-sm-4">
                <label for="pwd" class="form-label">Password</label>
                <input type="password" class="form-control" id="password" name="password" />
              </div>
              <div class="col-sm-4">
                <label for="role" class="form-label" id="role" name="role">Access/Role</label>
                <select class="form-select" id="role" name="role">
                  <option value="Select">Select Access/Role</option>
                  <option value="Cashier">Cashier</option>
                  <option value="Manager">Manager</option>
                </select>
              </div>
            </div>
            <button id="submit" name="submit" type="submit" class="btn mt-3" style="background-color: rgb(111, 111, 234);color: white;">Submit</button>
          </form>
                </div>
              </div>
            </div>
           
          </div>
        </div>
</form>
<!-- <script>
    function previewImage(event) {
        var reader = new FileReader();
        reader.onload = function() {
            var output = document.getElementById('imagePreview');
            output.src = reader.result;
            output.style.display = 'block'; 
        }
        reader.readAsDataURL(event.target.files[0]);
    }
</script> -->


<?php require APPROOT . '/views/inc/footer.php'; ?>