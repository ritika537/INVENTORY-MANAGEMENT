<?php require APPROOT . '/views/inc/header.php'; ?>
<?php require APPROOT . '/views/inc/adminnavbar.php'; ?>

<form action="<?php echo URLROOT; ?>inventorys/updateViewUser" method="post" enctype="multipart/form-data">
<input type ="hidden" id="id" name="id" value="<?php echo $data->id; ?>">
    <div class="container">
        <h1 class="mt-4 mb-5" style="color: rgb(111, 111, 234)"><b>EDIT USER INFORMATION</b></h1>
        <div class="row">
            <div class="col-md-12">
                <div class="card" style="box-shadow: 10px 25px 32px 0px rgb(179, 180, 181);">
                <div class="card-header  text-white" style="background-color: rgb(111, 111, 234);">Edit User Details</div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-sm-3">
                            <label for="fullname" class="form-label">Full Name</label>
                            <input type="text" class="form-control" id="name" name="name" value="<?php echo $data->name; ?>">
                        </div>
                        <div class="col-sm-3">
                            <label for="email" class="form-label">Email Address</label>
                            <input type="text" class="form-control" id="email" name="email" value="<?php echo $data->email; ?>" />
                        </div>
                        <div class="col-sm-3">
                            <label for="phone" class="form-label">Phone Number</label>
                            <input type="text" class="form-control" id="phone" name="phone" value="<?php echo $data->phone; ?>" />
                        </div>
                        <div class="col-sm-3">
                            <label for="dob" class="form-label">DOB</label>
                            <input type="date" class="form-control" id="dob" name="dob" value="<?php echo $data->dob; ?>" /> 
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-sm-3">
                            <label for="city" class="form-label">City</label>
                            <input type="text" class="form-control" id="city" name="city" value="<?php echo $data->city; ?>"/>
                        </div>
                        <div class="col-sm-3">
                            <label for="state" class="form-label">State</label>
                            <input type="text" class="form-control" id="state"  name="state" value="<?php echo $data->state; ?>"/>
                        </div>
                        <div class="col-sm-3">
                            <label for="pincode" class="form-label">Pincode</label>
                            <input type="text" class="form-control" id="pincode" name="pincode" value="<?php echo $data->pincode; ?>" />
                        </div>
                        <div class="col-sm-3">
                            <label for="address1" class="form-label">Address 1</label>
                            <input type="text" class="form-control" id="address1" name="address1" value="<?php echo $data->address1; ?>"/>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-sm-3">
                            <label for="address2" class="form-label">Address 2</label>
                            <input type="text" class="form-control" id="address2" name="address2" value="<?php echo $data->address2; ?>"/>
                        </div>
                        <div class="col-sm-3">
                            <label for="role" class="form-label" id="role" name="role" >Access/Role</label>
                            <select class="form-select" id="role" name="role" value="<?php echo $data->role; ?>">
                            <option value="Select">Select Access/Role</option>
                            <option value="Cashier">Cashier</option>
                            <option value="Manager">Manager</option>
                        </select>
                    </div>
                </div>
                <button id="save" name="save" type="submit" class="btn mt-3" style="background-color: rgb(111, 111, 234);color: white;">Save</button>
                <button id="back" name="back" type="submit" class="btn mt-3" style="background-color: rgb(111, 111, 234);color: white;">Back</button>
            </form>

