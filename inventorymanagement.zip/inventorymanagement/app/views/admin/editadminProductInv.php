<?php require APPROOT . '/views/inc/header.php'; ?>
<?php require APPROOT . '/views/inc/adminnavbar.php'; ?>

<form action="<?php echo URLROOT; ?>inventorys/updateadminProductInv" method="post" enctype="multipart/form-data">
<input type ="hidden" id="id" name="id" value="<?php echo $data->id; ?>">
    <div class="container">
        <h1 class="mt-4 mb-5" style="color: rgb(111, 111, 234)"><b>EDIT PRODUCT INFORMATION</b></h1>
        <div class="row">
            <div class="col-md-12">
                <div class="card" style="box-shadow: 10px 25px 32px 0px rgb(179, 180, 181);">
                <div class="card-header  text-white" style="background-color: rgb(111, 111, 234);">Edit Product Information</div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-sm-3">
                            <label for="pname" class="form-label">Product Name</label>
                            <input type="text" class="form-control" id="name" name="name" value="<?php echo $data->name; ?>" />
                        </div>
                        <div class="col-sm-3">
                            <label for="manu" class="form-label">MANUFACTURER</label>
                            <input type="text" class="form-control" id="mfg" name="mfg" value="<?php echo $data->mfg; ?>" />
                        </div>
                        <div class="col-sm-3">
                            <label for="availableQuantity" class="form-label">QUANTITY</label>
                            <input type="number" class="form-control" id="qty" name="qty" value="<?php echo $data->qty; ?>" />
                        </div>
                        <div class="col-sm-3">
                            <label for="pp" class="form-label">PURCHASE PRICE</label>
                            <input type="number" class="form-control" id="price" name="price" value="<?php echo $data->price; ?>" /> 
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-sm-3">
                            <label for="mrp" class="form-label">MRP</label>
                            <input type="number" class="form-control" id="mrp" name="mrp" value="<?php echo $data->mrp; ?>"/>
                        </div>
                        <div class="col-sm-3">
                            <label for="sp" class="form-label">SALE PRICE</label>
                            <input type="number" class="form-control" id="sale_price" name="sale_price" value="<?php echo $data->sale_price; ?>" />
                        </div>
                        <div class="col-sm-3">
                            <label for="category" id="category" name="category" value="<?php echo $data->category; ?>">CATEGORY</label>
                            <select class="form-select mt-2" id="category" name="category" value="<?php echo $data->category; ?>">
                                <option>-------------------select category--------------------</option>
                                <!-- <option><button>reload</button></option> -->
                                <option>ELECTRONICS</option>
                                <option>CLOTHES</option>
                                <option>COSMETICS</option>
                            </select>
                        </div>
                        <div class="col-sm-3">
              <label for="profileImage" class="form-label">Product Image</label>
              <input type="file" class="form-control" id="productImage" name="productImage" accept="image/*" value="<?php echo $data->image; ?>">
            </div>
                        <!-- <div class="col-sm-3">
                            <label for="address1" class="form-label">Address 1</label>
                            <input type="text" class="form-control" id="address1" name="address1" value="<?php echo $data->address1; ?>"/>
                        </div> -->
                    </div>
                    <!-- <div class="row">
                        <div class="col-sm-3">
                            <label for="address2" class="form-label">Address 2</label>
                            <input type="text" class="form-control" id="address2" name="address2" value="<?php echo $data->address2; ?>"/>
                        </div>
                        <div class="col-sm-3">
                            <label for="role" class="form-label" id="role" name="role" >Access/Role</label>
                            <select class="form-select" id="role" name="role" value="<?php echo $data->role; ?>">
                            <option value="Select">Select Access/Role</option>
                            <option value="Cashier">Cashier</option>
                            <option value="Manager">Manager</option>
                        </select>
                    </div>
                </div> -->
                <button id="save" name="save" type="submit" class="btn mt-3" style="background-color: rgb(111, 111, 234);color: white;">Save</button>
                <button id="back" name="back" type="submit" class="btn mt-3" style="background-color: rgb(111, 111, 234);color: white;">Back</button>
            </form>

