<?php require APPROOT . '/views/inc/header.php'; ?>
<?php require APPROOT . '/views/inc/navbar.php'; ?>

<form action="<?php echo URLROOT; ?>inventorys/uploaddashboard" method="post" enctype="multipart/form-data">
<div class="container">
    <div class="row justify-content-center mt-5">
                            <div class="col-md-8 col-lg-6">
                                <div class="card"style="box-shadow:0px 8px 32px 0px rgb(179,180,181);">
                                    <div class="card-header text-white text-center"style="background-color:rgb(111, 111, 234)">
                                        <h3>Invoice</h3>
                                    </div>
                                    <div class="card-body">
                                        <div class="invoice-container">
                                            <h2 class="text-center mb-4">Ganesh Mart</h2>
                                            <div class="text-center mb-4">
                                                <p>Lalji Hirji Road, Ranchi Jharkhand, 834001</p>
                                                <div class="row">
                                                    <div class="col">
                                                        <p>Customer Name:</p>
                                                    </div>
                                                    <div class="col">
                                                        <p>Phone No.:</p>
                                                    </div>
                                                </div>
                                                <div class="row">
                                                    <div class="col">
                                                        <p>Customer id:</p>
                                                    </div>
                                                    <div class="col">
                                                        <p>Date: <?php echo date('Y-m-d'); ?></p>
                                                    </div>
                                                </div>
                                            </div>
                                            
                                            <div class="table-responsive">
                                                <table class="table">
                                                    <thead>
                                                        <tr>
                                                            <th>S.No.</th>
                                                            <th>Description</th>
                                                            <th>Quantity</th>
                                                            <th>Price</th>
                                                            <th>Total</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        <tr>
                                                            <td>1</td>
                                                            <td>Item 1</td>
                                                            <td>2</td>
                                                            <td>Rs 10</td>
                                                            <td>Rs 20</td>
                                                        </tr>
                                                        <tr>
                                                            <td>2</td>
                                                            <td>Item 2</td>
                                                            <td>1</td>
                                                            <td>Rs 20</td>
                                                            <td>Rs 20</td>
                                                        </tr>
                                                    </tbody>
                                                    <tfoot>
                                                        <tr>
                                                            <td colspan="4">Total</td>
                                                            <td>Rs 40</td>
                                                        </tr>
                                                    </tfoot>
                                                </table>
                                            </div>
                                            <!-- <div class="text-right">
                                                <p><strong>GST: 8%</strong></p>
                                                <p><strong>SGST: 5%</strong></p>
                                                <p><strong>Discount: 5%</strong></p>
                                                <p><strong>Total Amount: Rs 43.092</strong></p>
                                            </div> -->
                                        </div>
                                        <p class="text-center mt-4"><b>You have saved Rs 2.50 Today!!!!!</b></p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>
<script>
    document.addEventListener('DOMContentLoaded', function() {
        // Fetch discount percent, order tax, and shopping from the server
        fetch('discount.php')
            .then(response => response.json())
            .then(data => {
                const discountPercent = parseFloat(data.discountPercent);
                const orderTax = parseFloat(data.orderTax);
                const shopping = parseFloat(data.shopping);

                // Perform operations based on fetched values
                const subtotals = document.querySelectorAll('.subtotal');
                let total = 0;
                subtotals.forEach(function(subtotal) {
                    total += parseFloat(subtotal.innerText);
                });
                const discount = total * (discountPercent / 100);
                const gst = total * (orderTax / 100);
                const totalAmount = total - discount + shopping + gst;

                // Update the UI with calculated values
                document.getElementById('discount-percent').innerText = discountPercent.toFixed(2);
                document.getElementById('order-tax').innerText = orderTax.toFixed(2);
                document.getElementById('shopping').innerText = shopping.toFixed(2);
                document.getElementById('total').innerText = total.toFixed(2);
                document.getElementById('discount').innerText = discount.toFixed(2);
                document.getElementById('gst').innerText = gst.toFixed(2);
                document.getElementById('total-amount').innerText = totalAmount.toFixed(2);
            })
            .catch(error => {
                console.error('Error fetching data:', error);
            });
    });
</script>

<?php require APPROOT . '/views/inc/footer.php'; ?>