<?php require APPROOT . '/views/inc/header.php'; ?>
<?php require APPROOT . '/views/inc/navbar.php'; ?>
<form action="<?php echo URLROOT; ?>inventorys/edituserProductInv" method="post" enctype="multipart/form-data">

<!-- <div class="container-fluid" >
                <?php $count = 0;
                foreach ($data as $dataline) {
                    if ($count % 4 == 0) {
                        echo '<div class="row  mt-4 "  >';
                    } ?>
                        <input type="hidden" value="<?php echo $dataline->id; ?>" name="<?php echo 'subcategory_type_id' . $count; ?>">
                        <div class="col-sm-3 my-3 ">
                            <div class="card text-center" style="padding:0px; border:2px solid white;box-shadow: 0px 4px 20px rgba(5,57,94,.5);">
                                <div class="card-body">
                                <img src="<?php echo URLROOT . "/img/amul-paneer-1-600x654.jpg"; ?>" class="image-fluid" height="250px" width="260px" alt="">
                        <h3 style="text-align:center"><?php echo $dataline->name; ?></h3>
                                        <h3 style="text-align:center"><?php echo $dataline->mrp; ?></h3>
                        <input type="hidden" value="<?php echo $dataline->subcategory_type; ?>" name="<?php echo 'subcategory_type' . $count; ?>">
                        <button class="btn " style="color:white;background:#6c89b4;width:100%"  id="<?php echo 'shop' . $count; ?>" name="<?php echo 'shop' . $count; ?>">Shop Now</button>
                            </div>
                         </div>
                        </div>
                    <?php '</div>' ?>
                    <?php $count++;
                } ?> 
             
               <input type="hidden" value="<?php echo $count; ?>" name="totalcount" id="totalcount">
                
            </div> -->
    <div class="container mt-5">
        <div class="row">
            <div class="col-md-12">
            <h1 class="mt-4 mb-5" style="color: rgb(111, 111, 234)"><b>PRODUCT INVENTORY</b></h1>
            </div>
            <?php $count = 0;
            foreach ($data as $dataline) {
                if ($count % 4 == 0) {
                    echo '<div class="row "  >';
                } ?>
                                           <input type="hidden" value="<?php echo $dataline->id; ?>" name="<?php echo 'id' . $count; ?>">
                                            <div class="col-sm-3 my-3 ">
                                                <div class="card h-100" style="padding:0px;border: none;box-shadow: 0px 20px 32px 0px rgb(179, 180, 181);">
                                                <div class="card-body">
                                                    <img src="<?php echo URLROOT . "/img/amul-paneer-1-600x654.jpg"; ?>" class="image-fluid" height="210px" width="220px" alt="">
                                                    <!-- <h3 style="text-align:center"><?php echo $dataline->name; ?></h3> -->
                                                    <h4 class="card-title"><?php echo $dataline->name; ?></h4>
                                                    <h6><b>BarCode:</b> <?php echo $dataline->bar_code; ?></h6>
                                                    <h6><b>Mfg:</b> <?php echo $dataline->mfg; ?></h6>
                                                    <h6><b>Category:</b> <?php echo $dataline->category; ?></h6>
                                                    <h6><b>Mrp: </b><?php echo $dataline->mrp; ?></h6>
                                                    <h6><b>Sales Price:</b> <?php echo $dataline->sale_price; ?></h6>
                                                    <h6><b>Qunatity:</b> <?php echo $dataline->qty; ?></h6>
                                                    <input type="hidden" value="<?php echo $dataline->subcategory_type; ?>" name="<?php echo 'subcategory_type' . $count; ?>">
                                                    <!-- <button class="btn " style="color:white;background:#6c89b4;width:100%"  id="<?php echo 'shop' . $count; ?>" name="<?php echo 'shop' . $count; ?>">Shop Now</button> -->
                                                    <div class="row">
                                                        <div class="col-sm-6">
                                                                <button style="border:none;" type="submit" id="<?php echo 'editbtn' . $count; ?>" name="<?php echo 'editbtn' . $count; ?>"><img src="<?php echo URLROOT . '/img/icons8-pencil-50.png'; ?>" alt="..." height="30px"></button>
                                                                <button style="border:none;" type="submit" id="<?php echo 'deletebtn' . $count; ?>" name="<?php echo 'deletebtn' . $count; ?>" ><img src="<?php echo URLROOT . '/img/delete.png'; ?>" alt="..." height="30px"></button>
                                                        </div>
                                                </div>
                                                </div>
                                            </div>
                                        </div>
                                        <?php '</div>' ?>
                                        <?php $count++;
            } ?> 
             
               <input type="hidden" value="<?php echo $count; ?>" name="totalcount" id="totalcount">
               
             <!-- <div class="col-md-3">

                <div class="card h-100" style="width: 18rem;margin-bottom: 24px">
                    <img src="<?php echo URLROOT . "/img/amul-paneer-1-600x654.jpg"; ?>" class="card-img-top" alt="...">
                    <div class="card-body">
                        <h5 class="card-title">Amul Paneer</h5>
                        <span><h6 id="Dairy">Diary</h6>
                        <span class="selling-price" style="font-size: 22px;
                                color: #000;
                                font-weight: 600;
                                margin-right: 8px;">Sale Price:-Rs 500
                        </span>
                        <h6 class="original-price" style="font-size: 18px;
                                color: #937979;
                                font-weight: 400;
                                ">Mrp:- Rs 799
                        </h6>
                        <h6 class="Quantity" style="font-size: 18px;
                                color: #937979;
                                font-weight: 400;
                                ">Quantity:- 30
                        </h6>

                    </div>
                </div>

            </div>  -->
            <!-- <div class="col-md-3">
            <div class="card h-100" style="width: 18rem;margin-bottom: 24px">
                    <img src="<?php echo URLROOT . "/img/banana cake.webp"; ?>" class="card-img-top" alt="...">
                    <div class="card-body">
                        <h5 class="card-title">Banana cake</h5>
                        <span><h6 id="Bakery">Bakery</h6>
                        <span class="selling-price" style="font-size: 22px;
                                color: #000;
                                font-weight: 600;
                                margin-right: 8px;">Sale Price:- Rs 500
                        </span>
                        <h6 class="original-price" style="font-size: 18px;
                                color: #937979;
                                font-weight: 400;
                                ">Mrp:- Rs 799
                        </h6>
                        <h6 class="Quantity" style="font-size: 18px;
                                color: #937979;
                                font-weight: 400;
                                ">Quantity:- 30
                        </h6>

                    </div>
                </div>
            </div> -->
            <!-- <div class="col-md-3">
            <div class="card h-100" style="width: 18rem;margin-bottom: 24px">
                    <img src="<?php echo URLROOT . "/img/lassi.jpeg"; ?>" class="card-img-top" alt="...">
                    <div class="card-body">
                        <h5 class="card-title">Amul Lassi</h5>
                        <span><h6 id="Dairy">Dairy</h6>
                        <span class="selling-price" style="font-size: 22px;
                                color: #000;
                                font-weight: 600;
                                margin-right: 8px;">Sale Price:- Rs 500
                        </span>
                        <h6 class="original-price" style="font-size: 18px;
                                color: #937979;
                                font-weight: 400;
                                ">Mrp:-Rs 799
                        </h6>
                        <h6 class="Quantity" style="font-size: 18px;
                                color: #937979;
                                font-weight: 400;
                                ">Quantity:- 30
                        </h6>

                    </div>
                </div>
            </div> -->
            <!-- <div class="col-md-3">
            <div class="card h-100" style="width: 18rem;margin-bottom: 24px">
                    <img src="<?php echo URLROOT . "/img/milk.jpg"; ?>" class="card-img-top" alt="...">
                    <div class="card-body">
                        <h5 class="card-title">Amul milk</h5>
                        <span><h6 id="Dairy">Dairy</h6>
                        <span class="selling-price" style="font-size: 22px;
                                color: #000;
                                font-weight: 600;
                                margin-right: 8px;">Sale Price:- $500
                        </span>
                        <h6 class="original-price" style="font-size: 18px;
                                color: #937979;
                                font-weight: 400;
                                ">Mrp:- $799
                        </h6>
                        <h6 class="Quantity" style="font-size: 18px;
                                color: #937979;
                                font-weight: 400;
                                ">Quantity:- 30
                        </h6>

                    </div>
                </div>
            </div> -->
        </div>
        <!-- <div class="row">
            <div class="col-md-3">
            <div class="card" style="width: 18rem;margin-bottom: 24px">
                    <img src="<?php echo URLROOT . "/img/key.jpeg"; ?>" class="card-img-top" alt="...">
                    <div class="card-body">
                        <h5 class="card-title">Mackein Fries</h5>
                        <span><h6 id="FROZEN FOOD">FROZEN FOOD</h6>
                        <span class="selling-price" style="font-size: 22px;
                                color: #000;
                                font-weight: 600;
                                margin-right: 8px;">Sale Price:-Rs 500
                        </span>
                        <h6 class="original-price" style="font-size: 18px;
                                color: #937979;
                                font-weight: 400;
                                ">Mrp:-Rs 799
                        </h6>
                        <h6 class="Quantity" style="font-size: 18px;
                                color: #937979;
                                font-weight: 400;
                                ">Quantity:- 30
                        </h6>

                    </div>
                </div>
            </div>
            <div class="col-md-3">
            <div class="card" style="width: 18rem;margin-bottom: 24px">
                    <img src="<?php echo URLROOT . "/img/key.jpeg"; ?>" class="card-img-top" alt="...">
                    <div class="card-body">
                        <h5 class="card-title">Ashirwad ATTA</h5>
                        <span><h6 id="Grocery">Grocery</h6>
                        <span class="selling-price" style="font-size: 22px;
                                color: #000;
                                font-weight: 600;
                                margin-right: 8px;">Sale Price:-Rs 500
                        </span>
                        <h6 class="original-price" style="font-size: 18px;
                                color: #937979;
                                font-weight: 400;
                                ">Mrp:- Rs 799
                        </h6>
                        <h6 class="Quantity" style="font-size: 18px;
                                color: #937979;
                                font-weight: 400;
                                ">Quantity:- 30
                        </h6>

                    </div>
                </div>
            </div>
            <div class="col-md-3">
            <div class="card" style="width: 18rem;margin-bottom: 24px">
                    <img src="<?php echo URLROOT . "/img/key.jpeg"; ?>" class="card-img-top" alt="...">
                    <div class="card-body">
                        <h5 class="card-title">Cold Drink</h5>
                        <span><h6 id="Confectionery">Confectionery</h6>
                        <span class="selling-price" style="font-size: 22px;
                                color: #000;
                                font-weight: 600;
                                margin-right: 8px;">Sale Price:- Rs 500
                        </span>
                        <h6 class="original-price" style="font-size: 18px;
                                color: #937979;
                                font-weight: 400;
                                ">Mrp:-Rs 799
                        </h6>
                        <h6 class="Quantity" style="font-size: 18px;
                                color: #937979;
                                font-weight: 400;
                                ">Quantity:- 30
                        </h6>

                    </div>
                </div>
            </div>
            <div class="col-md-3">
            <div class="card" style="width: 18rem;margin-bottom: 24px">
                    <img src="<?php echo URLROOT . "/img/key.jpeg"; ?>" class="card-img-top" alt="...">
                    <div class="card-body">
                        <h5 class="card-title">Mint Mojito</h5>
                        <span><h6 id="confectionery">Confectionery</h6>
                        <span class="selling-price" style="font-size: 22px;
                                color: #000;
                                font-weight: 600;
                                margin-right: 8px;">Sale Price:-Rs 500
                        </span>
                        <h6 class="original-price" style="font-size: 18px;
                                color: #937979;
                                font-weight: 400;
                                ">Mrp:-Rs 799
                        </h6>
                        <h6 class="Quantity" style="font-size: 18px;
                                color: #937979;
                                font-weight: 400;
                                ">Quantity:- 30
                        </h6>

                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-3">
            <div class="card" style="width: 18rem;margin-bottom: 24px">
                    <img src="<?php echo URLROOT . "/img/key.jpeg"; ?>" class="card-img-top" alt="...">
                    <div class="card-body">
                        <h5 class="card-title">Amul Milk Powder</h5>
                        <span><h6 id="Dairy">Dairy</h6>
                        <span class="selling-price" style="font-size: 22px;
                                color: #000;
                                font-weight: 600;
                                margin-right: 8px;">Sale Price:- Rs 500
                        </span>
                        <h6 class="original-price" style="font-size: 18px;
                                color: #937979;
                                font-weight: 400;
                                ">Mrp:- Rs 799
                        </h6>
                        <h6 class="Quantity" style="font-size: 18px;
                                color: #937979;
                                font-weight: 400;
                                ">Quantity:- 30
                        </h6>

                    </div>
                </div>
            </div>
            <div class="col-md-3">
            <div class="card" style="width: 18rem;margin-bottom: 24px">
                    <img src="<?php echo URLROOT . "/img/key.jpeg"; ?>" class="card-img-top" alt="...">
                    <div class="card-body">
                        <h5 class="card-title">Amul Chocolate</h5>
                        <span><h6 id="Grocery">Grocery</h6>
                        <span class="selling-price" style="font-size: 22px;
                                color: #000;
                                font-weight: 600;
                                margin-right: 8px;">Sale Price:-Rs 500
                        </span>
                        <h6 class="original-price" style="font-size: 18px;
                                color: #937979;
                                font-weight: 400;
                                ">Mrp:-Rs 799
                        </h6>
                        <h6 class="Quantity" style="font-size: 18px;
                                color: #937979;
                                font-weight: 400;
                                ">Quantity:- 30
                        </h6>

                    </div>
                </div>
            </div>
            <div class="col-md-3">
            <div class="card" style="width: 18rem;margin-bottom: 24px">
                    <img src="<?php echo URLROOT . "/img/key.jpeg"; ?>" class="card-img-top" alt="...">
                    <div class="card-body">
                        <h5 class="card-title">Keyboard</h5>
                        <span><h6 id="Category">Category</h6>
                        <span class="selling-price" style="font-size: 22px;
                                color: #000;
                                font-weight: 600;
                                margin-right: 8px;">Sale Price:- $500
                        </span>
                        <h6 class="original-price" style="font-size: 18px;
                                color: #937979;
                                font-weight: 400;
                                ">Mrp:- $799
                        </h6>
                        <h6 class="Quantity" style="font-size: 18px;
                                color: #937979;
                                font-weight: 400;
                                ">Quantity:- 30
                        </h6>

                    </div>
                </div>
            </div>
            <div class="col-md-3">
            <div class="card" style="width: 18rem;margin-bottom: 24px">
                    <img src="<?php echo URLROOT . "/img/key.jpeg"; ?>" class="card-img-top" alt="...">
                    <div class="card-body">
                        <h5 class="card-title">Keyboard</h5>
                        <span><h6 id="Category">Category</h6>
                        <span class="selling-price" style="font-size: 22px;
                                color: #000;
                                font-weight: 600;
                                margin-right: 8px;">Sale Price:- $500
                        </span>
                        <h6 class="original-price" style="font-size: 18px;
                                color: #937979;
                                font-weight: 400;
                                ">Mrp:- $799
                        </h6>
                        <h6 class="Quantity" style="font-size: 18px;
                                color: #937979;
                                font-weight: 400;
                                ">Quantity:- 30
                        </h6>

                    </div>
                </div>
            </div> -->
        </div>


    </div><!----conatiner band----->
</form>
</div>
</div>

</div>
<div class="row">
    <div class="col-sm-12">
        <?php require APPROOT . '/views/inc/footer.php'; ?>
    </div>
</div>