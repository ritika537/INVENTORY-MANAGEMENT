<?php require APPROOT . '/views/inc/header.php'; ?>
<?php require APPROOT . '/views/inc/navbar.php'; ?>
<form action="<?php echo URLROOT; ?>inventorys/addcustomerdetails" method="post" enctype="multipart/form-data">
    <h1 class="text-center mt-4" style="color: rgb(111, 111, 234)"><b> PRODUCT BILLING</b></h1>
    <div class="container">
        <button id="newbtn" name="newbtn" type="submit" class="btn" style="background-color: rgb(111, 111, 234);color: white; border:none;"> + New Customer</button>
        <div class="container mt-2" style="display: flex;justify-content: center;align-items: center;height: 100%;">
        <div class="card p-3" style="width: 100%;">
             <div class="card-body">
             <div class="row">
              
                <div class="col-sm-5">
                    <label for="customer" class="form-label">Customer Name</label>
                    <input type="text" class="form-control" id="name" name="name" placeholder="Input customer name" />
                </div>
                <div class="col-sm-6">
                    <label for="phone" class="form-label">Phone No.</label>
                    <input type="text" class="form-control" id="phone" name="phone" placeholder="Input customer phone no" />
                </div>
                <div class="col-sm-1">
                    <button id="save" name="save" type="submit" class="btn mt-4" style="color: white; border:none;width:100%;">
                    <img src="<?php echo URLROOT . '/img/save.png'; ?>" height="30px" alt=""></button>
                </div>
            </div>
        </form>
        <form action="<?php echo URLROOT; ?>inventorys/addBill" method="post" enctype="multipart/form-data">
                <div class="row">
                <input type ="hidden" name="id" id="id" value="<?php echo $data['customer_id']; ?>">
                    <div class="col-sm-4">
                        <label for="phone" class="form-label">Barcode</label>
                        <input type="text" class="form-control" id="barcode" name="barcode" placeholder="Enter Barcode No" />
                    </div>
                    <div class="col-sm-2 mt-4">
                    <button id="add" name="add" type="submit" class="btn mt-2" style="background-color: rgb(111, 111, 234);
                    color: white; border:none;width:100%;">
                     + Add</button>
                    </div>
                </div>
                
            </form>
            <hr style="border: 1px solid black;">
            <form  action="<?php echo URLROOT; ?>inventorys/insertBill" method="post" enctype="multipart/form-data">

            <!-- customer details -->
           
        <table class="table table-responsive table-hover table-sm mt-4">
            <tbody>
                <tr>
                <tr>
    <th>S.No.</th>
    <th>Product</th>
    <th>Price</th>
    <th>Qty</th>
    <th>Subtotal</th>
</tr>
<?php 
$count = 0;
foreach ($additionalData as $dataline) {
    echo '<tr>';?>
    <input type="hidden" name="<?php echo 'id' . $count; ?>" value="<?php echo $dataline->id; ?>">
    <input type="hidden" name="<?php echo 'name' . $count; ?>" value="<?php echo $dataline->product_name; ?>">
    <input type="hidden" name="<?php echo 'price' . $count; ?>" value="<?php echo $dataline->price; ?>">
    <th scope="row"><?php echo $count + 1; ?></th>
    <td><?php echo $dataline->product_name; ?></td>
    <td><?php echo $dataline->price; ?></td>
    <td>
        <input type="number" class="form-control" name="<?php echo 'quantity' . $count; ?>" value="1" min="1">
    </td>
    <td class="subtotal">
                    <?php echo $dataline->price; ?>
    </td>
    <td>
        <button style="border:none;"  id="<?php echo 'deletebtn' . $count; ?>" name="<?php echo 'deletebtn' . $count; ?>" value="<?php echo $dataline->id; ?>">
            <img src="<?php echo URLROOT . '/img/delete.png'; ?>" alt="..." height="30px">
        </button>
    </td>
<?php 
    echo '</tr>';
    $count++;
} 
?>  
<input type="hidden" value="<?php echo $count; ?>" name="totalcount" id="totalcount">

                        </tbody>
                    </table>
                </div>
                <!-- <div class="row">
                    <div class="col-sm-4">
                        <label for="otax" class="form-label">Order Tax (%)</label>
                        <input type="number" class="form-control" id="otax" name="otax" placeholder="0">

                    </div>
                    <div class="col-sm-4">
                        <label for="dis" class="form-label">Discount (%)</label>
                        <input type="number" class="form-control" id="dis" name="dis" placeholder="0">

                    </div>
                    <div class="col-sm-4">
                        <label for="shop" class="form-label">Shopping (%)</label>
                        <input type="number" class="form-control" id="shop" name="shop" placeholder="0">

                    </div>
                </div> -->
                <div class="row mt-4">
                    <div class="col-6"> 
                        <button class="btn" style="width: 100%;background-color: rgb(111, 111, 234);color: white;border:none;">Submit</button>
                    </div>
                    <!-- <div class="col-6">
                        <button class="btn" style="width: 100%;background-color: rgb(111, 111, 234);color: white;border:none;">Pay Now</button>
                    </div> -->
                    <div class="col-sm-6">
                    <div class="dropdown">
                        <button class="btn dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false"
                        style="width: 100%;background-color:rgb(111, 111, 234);color: white;border:none;">
                            Pay Now
                        </button>
                        <ul class="dropdown-menu" style="width:100%;">
                            <li><a class="dropdown-item active" href="#">Cash </a></li>
                            <li><a class="dropdown-item" href="#">UPI</a></li>
                            <li><a class="dropdown-item" href="#">Credit Card</a></li>
                        </ul>
                    </div>
                        </div>
                </div>
            </div>
        </div>
    </div>
</div>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
$(document).ready(function() {
    // Update subtotal when quantity changes
    $('input[name^="quantity"]').on('input', function() {
        var index = $(this).attr('name').match(/\d+/)[0]; // Extract index from input name
        var price = $('input[name="price' + index + '"]').val();
        var quantity = $(this).val();
        var subtotal = price * quantity;
        $(this).closest('tr').find('.subtotal').text(subtotal.toFixed(2)); // Update subtotal cell within the same row
        calculateTotal(); // Recalculate total
    });
      
          // Handle click event for delete buttons
    $('button[id^="deletebtn"]').on('click', function(e) {
        e.preventDefault(); // Prevent default form submission behavior
        var productId = $(this).val(); // Get the product ID from the button value or any other identifier you're using
        // Perform deletion action here, such as making an AJAX request to delete the product from the database
        // After successful deletion, you may want to remove the corresponding row from the table
        $(this).closest('tr').remove(); // Remove the row containing the delete button
        // Optionally, you can update the subtotal and total values if needed
    });

    // Function to calculate total
    function calculateTotal() {
        var total = 0;
        $('.subtotal').each(function() {
            total += parseFloat($(this).text());
        });
        $('#total').val(total.toFixed(2)); // Update hidden input for total
    }
});
</script>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz"
        crossorigin="anonymous"></script>
</form>