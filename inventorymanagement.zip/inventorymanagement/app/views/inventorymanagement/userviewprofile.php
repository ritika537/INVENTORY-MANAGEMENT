<?php require APPROOT . '/views/inc/header.php'; ?>
<?php require APPROOT . '/views/inc/navbar.php'; ?>

<form action="<?php echo URLROOT; ?>inventorys/viewProfile" method="post" enctype="multipart/form-data">
<div class="container pt-5 mt-5" style=" width: auto;position: absolute;top: 30%;left: 50%;transform: translate(-50%, -50%)">
        <div class="card mb-3" style="border: 1px solid #000000;box-shadow: 3px 3px #000000;
        transition: all 0.4s;">
       
             <div class="row g-0">
           
              <div class="col-md-4 mt-2 px-2 mb-2">
                <img src="<?php echo URLROOT . "/img/9442242.jpg"; ?>" class="img-fluid rounded-start" alt="...">
              </div>
              <div class="col-md-8">
                <div class="card-body">
                  <h2 class="card-title" style="color: rgb(111, 111, 234);"><b>Name of User</b></h2>
                  <!-- <p>User Id</p>
                  <p>Email Address</p>
                  <p>Phone Number</p>
                  <p>DOB</p> -->
                  <div class="row">
                    <div class="col-sm-6">User Id</div>
                    <div class="col-sm-6">Role</div>
                  </div>
                  <div class="row">
                    <div class="col-sm-6">Email</div>
                    <div class="col-sm-6">Phone No</div>
                  </div>
                  <div class="row">
                    <div class="col-sm-6">DOB</div>
                    <div class="col-sm-6">Pincode</div>
                  </div>
                  <div class="row">
                    <div class="col-sm-6">City</div>
                    <div class="col-sm-6">State</div>
                  </div>
                  <div class="row">
                    <div class="col-sm-12">Address</div>
                  </div>
                  <!-- <p class="card-text"><small class="text-body-secondary">Last updated 3 mins ago</small></p> -->
                </div>
              </div>
            </div>
          </div>
    </div>
  
            </form>
