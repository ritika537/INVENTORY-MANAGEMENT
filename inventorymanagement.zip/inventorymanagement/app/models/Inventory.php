<?php

class Inventory
{

    private $db;

    public function __construct()
    {

        $this->db = new Database;

    }

    public function insertUserInfo($fullname, $email, $phone, $dob, $city, $state, $pincode, $address1, $address2, $id, $password, $role, $imageName)
    {
        // Prepare SQL statement
        $this->db->query('INSERT INTO users(id, name, email, password, phone, role, city, state, pincode, address1, address2, dob, image) 
                      VALUES (0, :name, :email, :password, :phone, :role, :city, :state, :pincode, :address1, :address2, :dob, :image)');

        // Bind parameters
        $this->db->bind(':name', $fullname);
        $this->db->bind(':email', $email);
        $this->db->bind(':phone', $phone);
        $this->db->bind(':dob', $dob);
        $this->db->bind(':city', $city);
        $this->db->bind(':state', $state);
        $this->db->bind(':pincode', $pincode);
        $this->db->bind(':address1', $address1);
        $this->db->bind(':address2', $address2);
        $this->db->bind(':password', $password);
        $this->db->bind(':role', $role);
        $this->db->bind(':image', $imageName); // Add binding for the image file name

        // Execute the SQL statement
        if ($this->db->execute()) {
            return $this->db->insertId();
        } else {
            return false;
        }
    }

    public function idgetCustomerId($id){
        $this->db->query(' SELECT customer_id FROM customer_details WHERE id=:id ');
        $this->db->bind(':id', $id);
        $row = $this->db->single();
        return $row;  
    }
    public function addCustomerDetails($customer_id,$name,$phone,$createdTs,$createdBy){
        $this->db->query(' INSERT INTO customer_details(id,customer_id, customer_name, phone_no, created_ts, created_by) '
                .        ' VALUES (0,:customer_id,:name,:phone,:createdTs,:createdBy) ');
        $this->db->bind(':customer_id', $customer_id);
        $this->db->bind(':name', $name);
        $this->db->bind(':phone', $phone);
        $this->db->bind(':createdTs', $createdTs);
        $this->db->bind(':createdBy', $createdBy);
        if ($this->db->execute()) {
            $row = $this->db->insertId();
            return $row;
        } else {
            return false;
        }       
    }

    public function getProductDetails($barcode){
        $this->db->query(' SELECT  id,name,mrp,sale_price,qty,price  FROM product WHERE bar_code = :barcode ');
        $this->db->bind(':barcode', $barcode);
        $row = $this->db->single();
        return $row;
    }

     public function insertIntoBill($customerId,$name,$price,$qty,$sale_price,$createdTs,$createdBy){
        $this->db->query(' INSERT INTO billing_info(id,customer_id, product_name, price, quantity, sub_total,create_ts, created_by)'
                    .    ' VALUES (0,:customerId,:name,:price,:qty,:sale_price,:createdTs,:createdBy)');
        $this->db->bind(':name', $name);
        $this->db->bind(':customerId', $customerId);
        $this->db->bind(':price', $price);
        $this->db->bind(':qty', $qty);
        $this->db->bind(':sale_price', $sale_price);
        $this->db->bind(':createdTs', $createdTs);
        $this->db->bind(':createdBy', $createdBy);

        if ($this->db->execute()) {
            $row = $this->db->insertId();
            return $row;
        } else {
            return false;
        }              
     }


     public function getBillingProducts($customerId){
        $this->db->query('SELECT * FROM billing_info WHERE customer_id = :customerId ');
        $this->db->bind(':customerId', $customerId);
        $row = $this->db->resultSet();
        return $row;
     }
    

    public function insertRegistration($name, $email, $phone, $dob, $city, $state, $zip_code, $address, $password, $role,$image)
    {
        // Prepare SQL statement
        $this->db->query('INSERT INTO login(id, name, password, city, state, zip_code, phone, dob, role, address, image,email) 
                      VALUES (0, :name, :password, :city, :state, :zip_code, :phone, :dob, :role, :address, :image,:email)');

        // Bind parameters
        $this->db->bind(':name', $name);
        $this->db->bind(':password', $password);
        $this->db->bind(':city', $city);
        $this->db->bind(':state', $state);
        $this->db->bind(':zip_code', $zip_code);
        $this->db->bind(':phone', $phone);
        $this->db->bind(':dob', $dob);
        $this->db->bind(':role', $role);
        $this->db->bind(':address', $address);
        $this->db->bind(':image', $image);
        $this->db->bind(':email', $email);
        // Execute the SQL statement
        if ($this->db->execute()) {
            // Return the ID of the inserted record
            return $this->db->insertId();
        } else {
            // Return false if insertion fails
            return false;
        }
    }

    public function login_verification($data) {
        $this->db->query('SELECT * FROM login WHERE email = :email AND password = :password AND role = :role');
        $this->db->bind(':email', $data['email']);
        $this->db->bind(':password', $data['password']);
        $this->db->bind(':role', $data['role']);
        $this->db->execute();

        // Check if there is a matching user
        if ($this->db->rowCount() > 0) {
            return true; // Return true if credentials match
        } else {
            return false; // Return false if credentials do not match
        }
    }


    public function getAllUserView()
    {
        $this->db->query('SELECT * FROM users WHERE 1 = 1 ');
        $row = $this->db->resultSet();
        return $row;
    }

    public function deleteAllUserView($id)
    {
        $this->db->query('DELETE FROM users WHERE id = :id');
        $this->db->bind(':id', $id);
        if ($this->db->execute()) {
            return true;
        } else {
            return false;
        }
    }

    public function updateUserView($id, $name, $email, $phone, $dob, $city, $state, $pincode, $address1, $address2, $role)
    {
        $this->db->query('UPDATE users SET name=:name, email=:email, phone=:phone, dob=:dob, city=:city, 
        state=:state, pincode=:pincode,address1=:address1, address2=:address2, role=:role WHERE id=:id');
        $this->db->bind(':id', $id);
        $this->db->bind(':name', $name);
        $this->db->bind(':email', $email);
        $this->db->bind(':phone', $phone);
        $this->db->bind(':dob', $dob);
        $this->db->bind(':city', $city);
        $this->db->bind(':state', $state);
        $this->db->bind(':pincode', $pincode);
        $this->db->bind(':address1', $address1);
        $this->db->bind(':address2', $address2);
        $this->db->bind(':role', $role);


        if ($this->db->execute()) {
            return true;

        }
        return false;

    }
    public function getupdateUserView($id)
    {

        $this->db->query('SELECT id,name,email,phone,dob,city,state,pincode,address1,address2,role FROM users WHERE id=:id');
        $this->db->bind(':id', $id);
        $row = $this->db->single();
        // print_r($row);
        return $row;
    }

    // ADD PRODUCT*****************************************

    public function insertAddProduct($barcode, $pname, $mfg, $qty, $price, $mrp, $sales, $category, $imageName)
    {
        // Prepare SQL statement
        $this->db->query('INSERT INTO product(bar_code, name, mrp, sale_price, qty, mfg, category,'
            . 'price,image) VALUES (:bar_code, :name, :mrp, :sale_price, :qty, :mfg, '
            . ' :category, :price,:image)');

        // Bind parameters
        $this->db->bind(':bar_code', $barcode);
        $this->db->bind(':name', $pname);
        $this->db->bind(':mrp', $mrp);
        $this->db->bind(':sale_price', $sales);
        $this->db->bind(':qty', $qty);
        $this->db->bind(':mfg', $mfg);
        $this->db->bind(':category', $category);
        $this->db->bind(':price', $price);
        $this->db->bind(':image', $imageName);

        // Execute the SQL statement
        if ($this->db->execute()) {
            // Return the ID of the inserted record
            return $this->db->insertId();
        } else {
            // Return false if insertion fails
            return false;
        }
    }



    // insertAddCategory

    public function insertAddCategory($nameInput)
    {
        $this->db->query('INSERT INTO category(id,name) VALUES (0, :name)');
        // $this->db->bind(':status', $status);
        // $this->db->bind(':id', $categoryid);
        $this->db->bind(':name', $nameInput);
        if ($this->db->execute()) {
            $id = $this->db->insertId();
            return $id;

        } else {
            return false;
        }
    }

    // FETCHING USER SIDE PRODUCT INVENTORY
    public function getAllUserProduct()
    {
        $this->db->query('SELECT * FROM product WHERE 1 = 1 ');
        $row = $this->db->resultSet();
        return $row;
    }

    // EDIT/UPDATE USER PRODUCT INVENTORY
    public function deleteuserProductInv($id)
    {
        $this->db->query('DELETE FROM product WHERE id = :id');
        $this->db->bind(':id', $id);
        if ($this->db->execute()) {
            return true;
        } else {
            return false;
        }
    }

    public function updateuserProductInv($id, $name, $mrp, $sale_price, $qty, $mfg, $category)
    {
        $this->db->query('UPDATE product SET name=:name, mrp=:mrp, sale_price=:sale_price, qty=:qty, mfg=:mfg, 
            category=:category WHERE id=:id');
        $this->db->bind(':id', $id);
        $this->db->bind(':name', $name);
        $this->db->bind(':mrp', $mrp);
        $this->db->bind(':sale_price', $sale_price);
        $this->db->bind(':qty', $qty);
        $this->db->bind(':mfg', $mfg);
        $this->db->bind(':category', $category);
        // $this->db->bind(':price', $price);
        // $this->db->bind(':address1', $address1);
        // $this->db->bind(':address2', $address2);
        // $this->db->bind(':role', $role);


        if ($this->db->execute()) {
            return true;

        }
        return false;

    }
    public function getupdateuserProductInv($id)
    {

        $this->db->query('SELECT id,name,mrp,sale_price,qty,mfg,category FROM product WHERE id=:id');
        $this->db->bind(':id', $id);
        $row = $this->db->single();
        // print_r($row);
        return $row;
    }
    // FETCHING ADMIN SIDE PRODUCT INVENTORY

    public function getAllAdminProduct()
    {
        $this->db->query('SELECT * FROM product WHERE 1 = 1 ');
        $row = $this->db->resultSet();
        return $row;
    }

    // EDIT/UPDATE ADMIN PRODUCT INVENTORY
    public function deleteadminProductInv($id)
    {
        $this->db->query('DELETE FROM product WHERE id = :id');
        $this->db->bind(':id', $id);
        if ($this->db->execute()) {
            return true;
        } else {
            return false;
        }
    }

    public function updateadminProductInv($id, $name, $mrp, $sale_price, $qty, $mfg, $category, $price)
    {
        $this->db->query('UPDATE product SET name=:name, mrp=:mrp, sale_price=:sale_price, qty=:qty, mfg=:mfg, 
        category=:category, price=:price WHERE id=:id');
        $this->db->bind(':id', $id);
        $this->db->bind(':name', $name);
        $this->db->bind(':mrp', $mrp);
        $this->db->bind(':sale_price', $sale_price);
        $this->db->bind(':qty', $qty);
        $this->db->bind(':mfg', $mfg);
        $this->db->bind(':category', $category);
        $this->db->bind(':price', $price);
        // $this->db->bind(':address1', $address1);
        // $this->db->bind(':address2', $address2);
        // $this->db->bind(':role', $role);


        if ($this->db->execute()) {
            return true;

        }
        return false;

    }
    public function getupdateadminProductInv($id)
    {

        $this->db->query('SELECT id,name,mrp,sale_price,qty,mfg,category,price FROM product WHERE id=:id');
        $this->db->bind(':id', $id);
        $row = $this->db->single();
        // print_r($row);
        return $row;
    }

    // FETCHING ALL CATEGORY

    public function getAllCategory()
    {
        $this->db->query('SELECT * FROM category WHERE 1 = 1 ');
        $row = $this->db->resultSet();
        return $row;
    }

    public function deleteCategory($id)
    {
        $this->db->query('DELETE FROM category WHERE id = :id');
        $this->db->bind(':id', $id);
        if ($this->db->execute()) {
            return true;
        } else {
            return false;
        }
    }

    // public function updateCategory($id, $name)
    // {
    //     $this->db->query('UPDATE category SET name = :name WHERE id = :id');
    //     $this->db->bind(':id', $id);
    //     $this->db->bind(':name', $name);
    //     if ($this->db->execute()) {
    //         return true;
    //     } else {
    //         return false;
    //     }
    // }
    public function updateCategory($id, $name)
    {
        $this->db->query('UPDATE category SET name=:name WHERE id=:id');
        $this->db->bind(':id', $id);
        $this->db->bind(':name', $name);


        if ($this->db->execute()) {
            return true;

        }
        return false;

    }
    public function getupdateCategory($id)
    {

        $this->db->query('SELECT id,name FROM category WHERE id=:id');
        $this->db->bind(':id', $id);
        $row = $this->db->single();
        // print_r($row);
        return $row;
    }

    // FETCHING PRODUCT BILL HERE
    public function getAllBill()
    {
        $this->db->query('SELECT bar_code,name,price FROM product WHERE bar_code=:barcode;');
        $row = $this->db->single();
        return $row;
    }

    public function insertBill($name, $price)
    {
      
    }



    // *****************************



    public function getAllSwipImage()
    {
        $this->db->query('SELECT * FROM image_swip WHERE 1 = 1 ');
        $row = $this->db->resultSet();
        return $row;
    }

    public function editSwipImage($Id, $status)
    {
        $this->db->query('UPDATE image_swip SET status=:status  WHERE id = :id');
        $this->db->bind(':id', $Id);
        $this->db->bind(':status', $status);
        if ($this->db->execute()) {
            $id = $this->db->insertId();
            return true;
        } else {
            return false;
        }
    }

    public function insertNoticeToDisplay($status, $notice, $createdTs)
    {
        $this->db->query('INSERT INTO notice(id, notice, status, created_ts) VALUES (0,:notice,:status,:createdTs)');
        $this->db->bind(':status', $status);
        $this->db->bind(':notice', $notice);
        $this->db->bind(':createdTs', $createdTs);
        if ($this->db->execute()) {
            $Id = $this->db->insertId();
            return $Id;
        } else {
            return false;
        }
    }

    public function editNoticeByStatus($Id, $status)
    {
        $this->db->query('UPDATE notice SET status=:status  WHERE id = :id');
        $this->db->bind(':id', $Id);
        $this->db->bind(':status', $status);
        if ($this->db->execute()) {
            $id = $this->db->insertId();
            return true;
        } else {
            return false;
        }
    }


    public function getAllNotice()
    {
        $this->db->query(' SELECT * FROM notice WHERE 1 = 1 ');
        $row = $this->db->resultSet();
        return $row;
    }

    public function insertgalleryimage($image, $createdTs, $createdBy)
    {
        $this->db->query('INSERT INTO gallery(id, image, created_ts, created_by) VALUES (0,:image,:createdTs,:createdBy)');
        $this->db->bind(':image', $image);
        $this->db->bind(':createdBy', $createdBy);
        $this->db->bind(':createdTs', $createdTs);
        if ($this->db->execute()) {
            $Id = $this->db->insertId();
            echo "$Id";
            return $Id;
        } else {
            return false;
        }
    }

    public function getAllGalleryImage()
    {
        $this->db->query('SELECT id, image FROM gallery WHERE 1 = 1 ');
        $row = $this->db->resultSet();
        return $row;
    }

    public function deleteGalleryImage($Id)
    {
        $this->db->query('DELETE FROM gallery WHERE id = :id ');
        $this->db->bind(':id', $Id);
        if ($this->db->execute()) {
            return true;
        } else {
            return false;
        }
    }

    public function insertStudentAchievement()
    {
        $this->db->query('INSERT INTO student_acheivement(id, image, heading, created_ts) VALUES (0,:)');
        if ($this->db->execute()) {
            return true;
        } else {
            return false;
        }
    }

}

?>