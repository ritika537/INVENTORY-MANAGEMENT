<?php
  // DB Params
  define('DB_HOST', 'localhost');
  define('DB_USER', 'mhs');
  define('DB_PASS', 'mhs@123');
  define('DB_NAME', '5mr.mhs');

  // App Root
  define('APPROOT', dirname(dirname(__FILE__)));
  // URL Root
  define('URLROOT', 'https://5mr.marriyan.pentahead.in/public/');
  // Site Name
  define('SITENAME', 'Marriyan Health Science - Order Management');
  define('INSTITUTENAME', 'Marriyan Health Science - Order Management');
  // App Version
  define('APPVERSION', '1.0.0');